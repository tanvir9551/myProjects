<?php
//include './admin_area/includes/db.php';
include './headerMenuIndex.php';
include './function/function.php';
//include '../admin_area/indexMenu/headerMenuIndex.php';
?>
<div class="content-wrapper">             
    <section class="content">
        <!--<div class="panel-body" style="background-color: #ffffff">-->   
        <div class="panel-body" style="background-color: #f7981c">   
            <br>
            <br>  
            <br>  
            <br>  

            <div class="row" >
                <div class="box box-warning">
                    <div class="box-body" style='margin-left:13%;margin-top: 3%;background-color: orange'>
                        <div class="panel-info">
                            <?php
                            getProductDetailsByCategory();
                            ?>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </section>
</div>
<?php
include './footerMenuIndex.php';
//include 'adminFooterMenu.php';
?> 