<?php



$conn = mysqli_connect('localhost', 'root', '', 'greeting');

function getProductDetails() {
    global $conn;
    $get_pro = "select * from product_info";
    $run_get_pro = mysqli_query($conn, $get_pro);
    while ($row_pro = mysqli_fetch_array($run_get_pro)) {
        $product_id = $row_pro['id'];
        $product_name = $row_pro['product_name'];
        $product_desc = $row_pro['product_description'];
        $product_image = $row_pro['product_logo_nm'];

        echo "
                <div class='col-md-4'>
                <img src='../images/product_img/$product_image' width='180' height='180' alt='No image found' style='background-color: #000' class='img-responsive'>
               <p> <h6 class='text-yellow'>$product_name</h6>
                <a href='../showProducts.php?&id= " . $product_id . " target='_blank'>Read More...</a></p>                
             </div>
                            
";
    }
}

/*function getProductDetails4HomePage() {
    global $conn;
    $get_pro = "select * from product_info";
    $run_get_pro = mysqli_query($conn, $get_pro);
    while ($row_pro = mysqli_fetch_array($run_get_pro)) {
        $product_id = $row_pro['id'];
        $product_name = $row_pro['product_name'];
        $product_desc = $row_pro['product_description'];
        $product_image = $row_pro['product_logo_nm'];
        
        echo "
						
						<div class='item'>	
							<div class='glry-w3agile-grids agileits'> 
											<a href='products.html'><img src='images/$product_image' alt='img'></a>
											<div class='view-caption agileits-w3layouts'>           
	                                         <h4><a href='products.html' id ='".$row_pro['id']"' class='link-1'>$product_name</a></h4>
												<p>$product_desc</p>
												
											</div>   
							</div>   
						</div>
							
							
							
";
    }
}*/

function getProductDetailsByCategory() {
    global $conn;
    $cat_id = $_GET['catid'];
    $sql = "select * from product_info where product_cat='" . $cat_id . "'";
    $run_pro = mysqli_query($conn, $sql);
    while ($row_pro = mysqli_fetch_array($run_pro)) {
        $product_id = $row_pro['id'];
        $product_name = $row_pro['product_name'];
        $product_desc = $row_pro['product_description'];
        $product_image = $row_pro['product_logo_nm'];
        echo "
             <div class='col-md-4'>
                <img src='images/product_img/$product_image' width='180' height='180' alt='No image found' style='background-color: #000' class='img-responsive'>
               <p> <h6 class='text-yellow'>$product_name</h6>
                <a href='./showProducts.php?&id= " . $product_id . " target='_blank'><i class='fa fa-link'></i>Read More...</a></p>                
             </div>
    ";
    }
}

function getSingleProductDetailsById() {
    global $conn;
    $product_id = $_GET['id'];

// echo '<script>alert("'.$product_id.'")</script>';
    $get_pro = "select * from product_info where id = '" . $product_id . "'";
//    $get_pro = "select * from product_info";
    $run_get_pro = mysqli_query($conn, $get_pro);
    //echo $run_get_pro;
// echo '<script>alert("'.$get_pro.'")</script>';
    while ($row_pro = mysqli_fetch_array($run_get_pro)) {
        $product_id = $row_pro['id'];
        $product_name = $row_pro['product_name'];
        $product_desc = $row_pro['product_description'];
        $product_image = $row_pro['product_logo_nm'];

        echo "
        <div class='single_product'>
        <h1></h1>
             <div class='col-md-4'>
                <img src='images/product_img/$product_image' width='180' height='180' alt='No image found' sytle='background-color:black'>
                <p>$product_name</p>
                <span>$product_desc</span>        
             </div>
        </div>
    ";
    }
}
