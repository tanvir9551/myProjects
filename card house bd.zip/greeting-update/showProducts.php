<?php
include './admin_area/includes/db.php';
include './header.php';

//include '../admin_area/indexMenu/headerMenuIndex.php';
?>
<div class="content-wrapper">             
    <section class="content">
        <div class="panel-body" style="background-color: #f7981c">   
            <br>
            <br>  
            <br>  
            <br>  

            <div class="row" >
                <div class="box box-warning">    
                    <?php
                    if (isset($_GET['id'])) {
                        $id = $_GET['id'];
                       // echo '<script>alert("' . $cat_id . '")</script>';
                        $sql = "select * from product_info where id ='" . $id . "'";
                       // echo '<script>alert("' . $sql . '")</script>';
                        $result = mysqli_query($conn, $sql);
                        $row = mysqli_fetch_array($result);
                        $productName = $row['product_name'];
                        $productDescription = $row['product_description'];
                        $productimg = $row['product_logo_nm'];
                        ?>     

                        <div class="box-warning">
                            <div class="box-body">
                <!--                <table>
                                    <tr>
                                        <td>-->
                                <div class="col-lg-4 col-xs-4" style="margin-left:5%">
                                    <!-- small box -->
                                    <!--<div class="small-box">-->
                                    <!--<div class="small-box bg-lime">-->
                                    <div class="inner">
                                        <img src="images/product_img/<?php echo $row['product_logo_nm']; ?>" class="img-rounded" width="350px" height="250px" alt="image not found" style="background-color: #000"/>
                                    </div>                   
                                    <!--</div>-->
                                </div>
                                <!-- ./col -->
                                <!--                        </td>
                                                        <td>-->
                                <div class="col-lg-7 col-xs-7" style="padding-left: -10%">
                                    <!-- small box -->
                                    <!--<div class="small-box">-->
                                    <!--<div class="inner">-->
                                    <h2 class="text-green"> 
                                        <?php echo $productName; ?>  
                                    </h2>

                                    <h4> 
                                        <?php echo $productDescription; ?>
                                    </h4>
                                    <!--</div>-->                    
                                    <!--<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>-->
                                    <!--</div>-->
                                </div>
                                <!-- ./col -->
                                <!--                        </td>
                                                    </tr>
                                                </table>-->
                            </div>
                        </div>
                        <!--            <div class="box-body">
                                        <table align="center">
                                            <tr>
                                                <td>
                                                    <img src="<?php echo $row['product_logo_path']; ?>" class="img-rounded" width="350px" height="250px" />
                        
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <h1 class="text-green"> 
                        <?php echo $productName; ?>  
                                                    </h1>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td align="center">
                                                    <h3> 
                        <?php echo $productDescription; ?>
                                                    </h3>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>-->

                        <?php
                    }
                    ?>
                </div>
            </div> 
        </div>
    </section>
</div>
<?php
include './footer.php';
//include 'footer.php';
?> 