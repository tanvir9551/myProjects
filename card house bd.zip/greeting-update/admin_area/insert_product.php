<!DOCTYPE HTML>
<?php
include 'adminHeaderMenu.php';
?>

<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>

<div class="box box-warning">
    <?php
    if (isset($_POST['product_submit'])) {

        //getting the text from fields
        $product_title = $_POST['productTitle'];
        $product_desc = $_POST['productDesc'];
		$product_price = $_POST['productPrice'];
        $product_cat = $_POST['productCat'];
        //getting the image from field
        $product_image = $_FILES['productLogo']['name'];
        $tmp_dir = $_FILES['productLogo']['tmp_name'];
        $imgSize = $_FILES['productLogo']['size'];

        if (empty($product_title)) {
            $errMSG = "Please Enter Product Name.";
            echo '<h1 class="text-red" align="center">Please Enter Product Name.</h1>';
        } else if (empty($product_image)) {
            $errMSG = "Please Select Image File.";
            echo '<h1 class="text-red" align="center">Please Select Image File.</h1>';
        } else if (empty($product_desc)) {
            $errMSG = "Please Enter Product Description.";
            echo '<h1 class="text-red" align="center">Please Enter Product Description.</h1>';
        } else {
            $sql = "select product_logo_nm from product_info where product_logo_nm = '" . $product_image . "'";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_array($result);
            $productImg = $row['product_logo_nm'];
            // echo $sql;
//                return false;
            if ($productImg) {
                $errMSG = "Product Logo Already Inserted";
                echo '<h1 class="text-red" align="center">Product Logo Already Inserted</h1>';
            } else {

//    if($product_image){
                $upload_dir = '../images/product_img/'; // upload directory 

                $imgExt = strtolower(pathinfo($product_image, PATHINFO_EXTENSION)); // get image extension
                // valid image extensions
                $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
                // rename uploading image
                $userpic = rand(1000, 1000000) . "." . $imgExt;

                // allow valid image file formats
                if (in_array($imgExt, $valid_extensions)) {
                    // Check file size '1MB'
                    if ($imgSize < 1000000) {
                        move_uploaded_file($tmp_dir, "$upload_dir$product_image");
//     move_uploaded_file($tmp_dir,$upload_dir.$userpic);
                    } else {
                        $errMSG = "Sorry, your file is too large.";
                        echo '<h1 class="text-red" align="center">Sorry, your file is too large.</h1>';
                    }
                } else {
                    $errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                    echo '<h1 class="text-red" align="center">Sorry, only JPG, JPEG, PNG & GIF files are allowed.</h1>';
                }
            }
        }
//    move_uploaded_file($tmp_dir, "../images/product_img/$product_image");
        // if no error occured, continue ....
        if (!isset($errMSG)) {
            $product_img_path = "../images/product_img/" . $product_image;
            $sql = "insert into product_info(product_name,product_description,product_logo_nm,logo_size,product_logo_path,product_cat,entry_date,product_price) values('$product_title','$product_desc','$product_image','$imgSize','$product_img_path','$product_cat',now(),'$product_price')";
            $insert_pro = mysqli_query($conn, $sql);
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            if ($insert_pro) {
//        echo '<script>alert("Data save successfully!!!!!")</script>';
                echo '<h3 class="text-green" align="center">Data save successfully!!!!!</h3>';
                echo '<script>window.open("insert_product.php","_self")</script>'; //open targated page
            } else {
                echo 'oh!sorry!!';
            }
        }
    }
    ?>

    <form action="insert_product.php" enctype="multipart/form-data" method="post" class="form-horaizontal">
        <div class="box-header btn-success">
            <h3 class="panel-title text-bold" style="color: #ffffff">Create New Product</h3>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="form-group">
                    <label class="col-md-2 control-label">Product Title</label>
                    <div class="col-lg-8 col-xs-5">
                        <input type="text" name="productTitle" value="" class="form-control" id="">
                    </div>
                </div>
            </div>&nbsp;
            <div class="row">
                <div class="form-group">
                    <label class="col-md-2 control-label">Product Category</label>
                    <div class="col-lg-8 col-xs-5">
                        <select name="productCat" class="form-control">
                            <option>Select Product Category</option>
                            <?php
                            $get_cat = "select id, category_title from product_category";
                            $result = mysqli_query($conn, $get_cat);
                            while ($rows = mysqli_fetch_array($result)) {
                                $cat_id = $rows['id'];
                                $cat_title = $rows['category_title'];
                                echo "<option value='$cat_title' >$cat_title</option>";
                                echo $cat_title;
                            }
                            ?>
                        </select>

                    </div>
                </div>
            </div>&nbsp;
			

            <div class="row">
                <div class="form-group">
                    <label class="col-md-2 control-label">Product Logo</label>
                    <div class="col-lg-8 col-xs-5">
                        <div class="input-group">
                            <span class="input-group-btn">
                                <span class="btn btn-warning btn-file">
                                    Browse  &hellip;
                                    <input type="file" id="picName" name="productLogo"
                                           class="fileName" >
										  
                                </span>
                            </span>
							
							
                            <input type="text" class="form-control tf" readonly="readonly" id="productLogos"
                                   name="productLogos"
                                   placeholder ="Browse your file" class="form-control input-sm"  >
								

                        </div>
                    </div>
                </div>
            </div>&nbsp;
			<div class="row">
                <div class="form-group">
                    <label class="col-md-2 control-label">Product Price</label>
                    <div class="col-lg-8 col-xs-5">
                        <input type="text" name="productPrice" value="" class="form-control" id="">
                    </div>
                </div>
            </div>&nbsp;
            <div class="row"> 
                <div class="form-group">
                    <label class="col-md-2 control-label">Product Description</label>                                       
                    <div class="col-lg-8 col-xs-5">
                        <textarea cols="50" rows="15" name="productDesc"  value="" class="" id=""></textarea>
                    </div>
                </div>
            </div>&nbsp;
            <div class="row">
                <div class="col-lg-8 col-xs-5">
                    <div class="form-group">
                        <label class="col-md-2 control-label"></label>
                    </div>
                </div>
            </div>
        </div>
        <div class="box-footer" style="margin-left: 35%">
            <button type="submit" name="product_submit" class="btn btn-foursquare p-r-5" id="submit"><i class="fa fa-save"></i> Save Product</button>
            <button type="reset" class="btn btn-info" ><i class="fa fa-refresh"></i> Reset Product</button>

        </div><!-- /.box-footer -->
    </form>
</div>


<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="//cdn.ckeditor.com/4.5.6/full/ckeditor.js"></script>
<!--<script src="//cdn.ckeditor.com/4.5.10/standard/ckeditor.js"></script>-->
<!--<script src="//cdn.ckeditor.com/4.5.10/basic/ckeditor.js"></script>-->
<script>
    $(document).ready(function () {
        CKEDITOR.replace('productDesc');
        $(document).on('change', '#picName', function () {
            var value = this.value;
            if (value) {
                $("#productLogos").val(value);
            }
        });
    });
</script>
<?php
//error_reporting( ~E_NOTICE ); // avoid notice
include './adminFooterMenu.php';
?>

