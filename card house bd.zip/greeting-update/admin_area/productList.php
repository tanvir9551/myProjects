<?php
include 'adminHeaderMenu.php';
//include '../function/function.php';
?>
<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>

<div class="box box-warning">
    <!--<div class="box-body">-->
        <div class="box-header btn-google">
            <h3 class="panel-title">Product List</h3>
        </div>
        <div class="box-body">
             <table class="table table-striped table-bordered table-hover " id="dataTable">
            <thead class="btn-success ">
                <tr>
                    <th>Product Name</th>
                    <!--<th>Product Description</th>-->
                    <th>Product Image</th>
                    <th>Product Entry Date</th>
                    <th>Product Update Date</th>
                    <th>Action</th> 
                </tr>        
            </thead>
            <tbody>
                <?php
                $sql = "select * from product_info";
                $result = mysqli_query($conn, $sql);
                if ($result->num_rows > 0) {
                    // output data of each row
//                        data-toggle='modal' data-target='#myModal'
                    while ($row = $result->fetch_assoc()) {
//                    echo "<tr>" . "<td>" . $row["product_name"] . "</td> " . "<td>" . "<img src='" . $row["product_logo_path"] . "' height='50px' width='60px' alt='No image found'>" . " </td> " . "<td>" . $row["entry_date"] . "</td>" . "<td>" . $row["update_date"] . "</td>" . " <td><a href='productList.php?action=show&id= " . $row["id"] . "' class='btn btn-info btn-xs' data-toggle='modal' data-target='#myModal'>View Product Details <i class='fa fa-file-text-o'></i></a>&nbsp; <a href='editProduct.php?id= " . $row["id"] . "' class='btn btn-warning btn-xs' target='_blank' >Edit Product <i class='fa fa-fw fa-edit'></i></a> &nbsp;<a href='productList.php?action=delete&id= " . $row["id"] . "' class='btn btn-danger btn-xs'> Delete Product <i class='fa fa-fw fa-eraser'></i></a></td> " . " </tr> ";
                        echo "<tr>" . "<td>" . $row["product_name"] . "</td> " . "<td>" . "<img src='" . $row["product_logo_path"] . "' height='50px' width='60px' alt='No image found'>" . " </td> " . "<td>" . $row["entry_date"] . "</td>" . "<td>" . $row["update_date"] . "</td>" . " <td><a href='productSingleView.php?&id= " . $row["id"] . "' class='btn btn-info btn-xs' target='_blank'>View Product Details <i class='fa fa-file-text-o'></i></a>&nbsp; <a href='editProduct.php?id= " . $row["id"] . "' class='btn btn-warning btn-xs' target='_blank' >Edit Product <i class='fa fa-fw fa-edit'></i></a> &nbsp;<a href='productList.php?action=delete&id= " . $row["id"] . "' class='btn btn-danger btn-xs'> Delete Product <i class='fa fa-fw fa-eraser'></i></a></td> " . " </tr> ";
//                            echo "<tr>" . "<td>" . $row["product_name"] . "</td> " . "<td>" . $row["product_description"] . "<td>" . "<img src='" . $row["product_logo_path"] . "' height='50px' width='60px' alt='No image found'>" . " </td> " . " </td> " . " <td><a href='productList.php?action=show&id= " . $row["id"] . "' class='btn btn-info btn-xs' data-toggle='modal' data-target='#myModal'>View <i class='fa fa-fw fa-eraser'></i></a>&nbsp; <a href='productList.php?action=edit&id= " . $row["id"] . "' class='btn btn-warning btn-xs' >Edit <i class='fa fa-fw fa-edit'></i></a>&nbsp;<a href='productList.php?action=delete&id= " . $row["id"] . "' class='btn btn-danger btn-xs'>Delete <i class='fa fa-fw fa-eraser'></i></a></td> " . " </tr> ";
                    }
                } else {
                    echo "<tr><td colspan='5' align='center'>No Record Found!!!!</td>";
                }

                if (isset($_GET['action'])) {
                    switch ($_GET['action']) {
                        case 'delete':
                            $id = $_GET["id"];
                            $get_pro = "select * from product_info where id= '" . $id . "'";
                            $run_get_pro = mysqli_query($conn, $get_pro);
                            $row_pro = mysqli_fetch_array($run_get_pro);

                            $path = $row_pro['product_logo_path'];
                            unlink($path);
                            $sql = "delete from product_info where id= '" . $id . "'";
                            $result = mysqli_query($conn, $sql);

                            echo "<h3 class='text-green' align = 'center'>Record successfully deleted</h3>\n";
//                                echo "<h1 class="text-green" align="center">Deleted data successfully</h1>\n";
                            echo '<script>window.open("productList.php","_self")</script>';
                            break;
                    }
                }
                $conn->close();
                ?>


            </tbody>
        </table>
        </div>
    <!--</div>-->    
</div>
<script type="text/javascript">
    $(document).ready(function () {
        //    $('#example').DataTable();
        $('#dataTable').dataTable({
            "bProcessing": true,
            "sAjaxSource": "Json/CustomerListJson.php",
            "sScrollX": "70%",
            "sScrollXInner": "110%",
            "bScrollCollapse": true,
            "bDestroy": true,
            "bJQueryUI": true
        });
    });
</script>
<!-- /.content -->
<?php
include 'adminFooterMenu.php'
?>