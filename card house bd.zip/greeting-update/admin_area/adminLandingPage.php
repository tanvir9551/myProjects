<?php
//include './includes/db.php';
include 'adminHeaderMenu.php';
?>
<!-- Content Wrapper. Contains page content -->

<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>

<!-- Main content -->
<div class="box box-warning">
    <div class="box-body">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-aqua-gradient">
                    <div class="inner">
                        <?php
                        $sql = "select * from product_info";
                        $result = mysqli_query($conn, $sql);
                        if ($result) {
                            $rowcount = mysqli_num_rows($result);
                            echo ''
                            . '<h3>' . $rowcount . '</h3>'
                            . '<p>Total Number Of Products</p>';
                            // printf("Result set has %d rows.\n", $rowcount);
                            // Free result set
                            mysqli_free_result($result);
                        }
                        //mysqli_close($conn);
                        ?>          
                    </div>
                    <div class="icon">

                        <i class="ion ion-bag"></i>
                    </div>
                    <a href="productList.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-green-gradient">
                <!--<div class="small-box bg-lime">-->
                    <div class="inner">
                        <h3>53<sup style="font-size: 20px">%</sup></h3>

                        <p>Total number of order</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-light-blue-gradient">
                    <div class="inner">
                        <h3>65</h3>

                        <p>Total sells</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-maroon-gradient">
                    <div class="inner">
                        <?php
                        $sql = "select * from user_info";
                        $result = mysqli_query($conn, $sql);
                        if ($result) {
                            $rowcount = mysqli_num_rows($result);
                            echo ''
                            . '<h3>' . $rowcount . '</h3>'
                            . '<p>Total Number Of User</p>';
                            // printf("Result set has %d rows.\n", $rowcount);
                            // Free result set
                            mysqli_free_result($result);
                        }
                        mysqli_close($conn);
                        ?> 
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="userList.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->        
        </div>
        <!-- /.row -->
        <!-- Main row -->

        <!-- /.row (main row) -->

    </div>
</div>
<!-- /.content -->

<?php
include './adminFooterMenu.php'
?>