<?php
//ob_start();
include 'adminHeaderMenu.php';
?>
<div class="box box-warning">    
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "select * from product_info where id ='" . $id . "'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        $productName = $row['product_name'];
        $productDescription = $row['product_description'];
        $productimg = $row['product_logo_nm'];
        ?>     

<!--        <div class="box-warning">-->
 <div class="box-header btn-google">
                <h3 class="panel-title">Product Details</h3>
            </div>
            <div class="box-body">
<!--                <table>
                    <tr>
                        <td>-->
                            <div class="col-lg-4 col-xs-4">
                                <!-- small box -->
                                <!--<div class="small-box">-->
                                <!--<div class="small-box bg-lime">-->
                                <div class="inner">
                                    <img src="<?php echo $row['product_logo_path']; ?>" class="img-rounded" width="350px" height="250px" />
                                </div>                   
                                <!--</div>-->
                            </div>
                            <!-- ./col -->
<!--                        </td>
                        <td>-->
<div class="col-lg-8 col-xs-8" style="padding-left: 20px">
                                <!-- small box -->
                                <!--<div class="small-box">-->
                                <!--<div class="inner">-->
                                    <h2 class="text-green"> 
                                        <?php echo $productName; ?>  
                                    </h2>

                                    <h4> 
                                        <?php echo $productDescription; ?>
                                    </h4>
                                    <!--</div>-->                    
                                    <!--<a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>-->
                                <!--</div>-->
                            </div>
                            <!-- ./col -->
<!--                        </td>
                    </tr>
                </table>-->
            </div>
        </div>
       
        <?php
    }
    ?>
</div>

<?php
//include '../footerMenuIndex.php';
include 'adminFooterMenu.php';
?>
