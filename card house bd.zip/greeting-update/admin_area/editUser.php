<?php
include 'adminHeaderMenu.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    if (isset($_POST['user_update'])) {
        $fNames = $_POST['fullName'];
        $uNames = $_POST['userName'];
        $uPasss = $_POST['password'];
        $email = $_POST['email'];
        $cellPhone = $_POST['contactNo'];
        
        if ($uNames && $uPasss) {
            $sql = "select user_name,is_admin from user_info where user_name = '" . $uNames . "' AND id !='". $id."'";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_array($result);
            $userName = $row['user_name'];
            $admin = $row['is_admin'];
           
            if(isset($_POST["isAdmin"])==0){
              $isAdmins = 0;
            }  else if(isset($_POST["isAdmin"])==1){
                $isAdmins = 1;   
            }  else {
                $isAdmins = $admin;
            }
            if ($userName) {
                echo '<h1 class="text-red" align="center">Duplicate user name found! Please try another one</h1>';
            } else if (!$userName) {
                $sql = "UPDATE user_info SET 
        full_name='$fNames', user_name='$uNames', password='$uPasss',email='$email',contact_no='$cellPhone',is_admin='$isAdmins',update_date = now() WHERE id='$id'"; // or die()

                $updated = mysqli_query($conn, $sql);
                if ($updated) {
                    $msg = "Successfully Updated!!";
                    echo '<script>window.open("userList.php","_self")</script>';
                }
            }
        }
    }
}
?>

<?php
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'delete':
            $id = $_GET["id"];
            $get_pro = "select * from user_info where id= '" . $id . "'";
            echo '<script>alert("' . $get_pro . '")</script>';
            $run_get_pro = mysqli_query($conn, $get_pro);
            $row_pro = mysqli_fetch_array($run_get_pro);
            $sql = "delete from user_info where id= '" . $id . "'";
            $result = mysqli_query($conn, $sql);

            echo "<h3 class='text-green' align = 'center'>Record successfully deleted</h3>\n";
////                                echo "<h1 class="text-green" align="center">Deleted data successfully</h1>\n";
            echo '<script>window.open("userList.php","_self")</script>';
            break;
    }
}
?>

<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>

<div class="box box-warning">
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "select * from user_info where id ='" . $id . "'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        $userId = $row['id'];
        $fNames = $row['full_name'];
        $uNames = $row['user_name'];
        $uPasss = $row['password'];
        $email = $row['email'];
        $cellPhone = $row['contact_no'];        
//        $isAdminRow = $row['is_admin'];
        $isAdmins = isset($_POST["isAdmin"]) ? $_POST["isAdmin"] : $row['is_admin'];
        ?>    
            <form action="" enctype="multipart/form-data" method="post" class="form-horaizontal" role="form">

                <div class="box-header btn-success">
                    <h3 class="panel-title text-bold" style="color: #ffffff">Edit User for Zayan Technology</h3>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="form-group">
                            <label class="control-label col-md-2">Full Name</label>
                            <div class="col-xs-6 col-sm-12 col-md-6">
                                <input type="text" name="fullName" id="fullName" class="form-control input-sm" value="<?php echo $fNames; ?>" placeholder="Full Name">
                            </div>
                        </div>
                    </div>&nbsp;
                    <div class="row">
                        <div class="form-group">
                            <label class="control-label col-md-2">contact No</label>
                            <div class="col-xs-6 col-sm-12 col-md-6">
                                <input type="text" name="contactNo" id="contactNo" class="form-control input-sm" value="<?php echo $cellPhone; ?>" placeholder="contact No">
                            </div>
                        </div>
                    </div>&nbsp;
                    <div class="row">
                        <div class="form-group">
                            <label class="control-label col-md-2">Email Address</label>
                            <div class="col-xs-6 col-sm-12 col-md-6">
                                <input type="email" name="email" id="email" class="form-control input-sm" value="<?php echo $email; ?>" placeholder="Email Address">
                            </div>
                        </div>
                    </div>&nbsp;
                    <div class="row">
                        <div class="form-group">
                            <label class="control-label col-md-2">User Name</label>
                            <div class="col-xs-6 col-sm-12 col-md-6">
                                <input type="text" name="userName" id="userName" class="form-control input-sm" value="<?php echo $uNames; ?>" placeholder="User Name">
                            </div>
                        </div>
                    </div>&nbsp;
                    <div class="row">
                        <div class="form-group">
                            <label class="control-label col-md-2">Password</label>
                            <div class="col-xs-6 col-sm-12 col-md-6">
                                <input type="password" name="password" id="password" class="form-control input-sm" value="<?php echo $uPasss; ?>" placeholder="Password">
                            </div>
                        </div>
                    </div>&nbsp;
                    <div class="row">
                        <div class="col-xs-6 col-sm-12 col-md-6">
                            <div class="form-group">
                                <div class="col-md-2" style="margin-left: -12px">
                                    <?php
                                            if ($isAdmins==1){
                                                echo '<input type="checkbox" name="isAdmin" checked="true" value="1">'; 
                                            }  else {
                                              echo '<input type="checkbox" name="isAdmin"  value="0">';   
                                            }
                                    ?>
                                    
                                </div>                                            
                                <label class="" style="color: #4B6170;margin-left: -15px ">Is Admin</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer" style="margin-left: 35%">
                    <button type="submit" name="user_update" class="btn btn-success p-r-5" id="submit"><i class="fa fa-save"></i> Update User</button>
                    <!--<button type="reset" class="btn btn-danger" ><i class='fa fa-fw fa-eraser'></i></i> Delete Product</button>-->
                    <a href="user_controller.php?action=delete&id='<?php echo $userId; ?>' " class='btn btn-danger'> Delete User <i class='fa fa-fw fa-eraser'></i></a>
                </div><!-- /.box-footer -->
            </form>
        </div>
        <?php
    }
    ?>
    <?php
    include 'adminFooterMenu.php'
    ?>
