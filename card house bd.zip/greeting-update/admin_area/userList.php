<?php
include 'adminHeaderMenu.php';
//include '../function/function.php';
?>
<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>

        <div class="box box-warning">
             <div class="box-header btn-google">
                <h3 class="panel-title">User List</h3>
            </div>
            <div class="box-body">
               
            <table class="table table-striped table-bordered table-hover " id="dataTable">
                <thead class="btn-success ">
                    <tr>
                        <th>User Name</th>
                        <!--<th>Product Description</th>-->
                        <th>Admin User?</th>
                        <th>User Entry Date</th>
                        <th>Action</th> 
                    </tr>        
                </thead>
                <tbody>
                    <?php
                    $sql = "select * from user_info";
                    $result = mysqli_query($conn, $sql);
                    if ($result->num_rows > 0) {
                        // output data of each row
//                        data-toggle='modal' data-target='#myModal'
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>" . "<td>" . $row["user_name"] . "</td> " ."<td>".$row["is_admin"] ." </td> " ."<td>".$row["created_date"] . "</td>". " <td><a href='editUser.php?id= " . $row["id"] . "' class='btn btn-warning btn-xs' >Edit <i class='fa fa-fw fa-edit'></i></a>&nbsp;<a href='userList.php?action=delete&id= " . $row["id"] . "' class='btn btn-danger btn-xs'>Delete <i class='fa fa-fw fa-eraser'></i></a></td> " . " </tr> ";
//                            echo "<tr>" . "<td>" . $row["user_name"] . "</td> " ."<td>". "<img src='" . $row["product_logo_path"] . "' height='50px' width='60px' alt='No image found'>" . " </td> " ."<td>".$row["entry_date"] . "</td>". " <td><a href='productList.php?action=show&id= " . $row["id"] . "' class='btn btn-info btn-xs' data-toggle='modal' data-target='#myModal'>View <i class='fa fa-fw fa-eraser'></i></a>&nbsp; <a href='productList.php?action=edit&id= " . $row["id"] . "' class='btn btn-warning btn-xs' >Edit <i class='fa fa-fw fa-edit'></i></a>&nbsp;<a href='productList.php?action=delete&id= " . $row["id"] . "' class='btn btn-danger btn-xs'>Delete <i class='fa fa-fw fa-eraser'></i></a></td> " . " </tr> ";
                        }
                    } else {
                        echo "0 results";
                    }

                    if (isset($_GET['action'])) {
                        switch ($_GET['action']) {
                            case 'show':
                                $id = $_GET["id"];
                                $get_pro = "select * from product_info where id = '" . $id . "'";
                                $run_get_pro = mysqli_query($conn, $get_pro);
                                $row_pro = mysqli_fetch_array($run_get_pro);
                                echo $get_pro;
                                // $product_id = $row_pro['id'];
                                $product_name = $row_pro['product_name'];
                                $product_desc = $row_pro['product_description'];
                                $product_image = $row_pro['product_logo_path'];
                                /* -- Modal */
                                echo "
                                     ";
                                break;
                            case 'edit':
                                $id = $_GET["id"];
                                $sql = "select * from product_info where id= '" . $id . "'";
                                $result = mysqli_query($conn, $sql);
                                echo "<h3 class='text-green' align = 'center'>Record successfully deleted</h3>\n";
//                                echo "<h1 class="text-green" align="center">Deleted data successfully</h1>\n";
                                echo '<script>window.open("editProduct.php","_self")</script>';
                                break;
                            case 'delete':
                                $id = $_GET["id"];
                                $sql = "delete from user_info where id= '" . $id . "'";
                                $result = mysqli_query($conn, $sql);
                                echo "<h3 class='text-green' align = 'center'>Record successfully deleted</h3>\n";
//                                echo "<h1 class="text-green" align="center">Deleted data successfully</h1>\n";
                                echo '<script>window.open("userList.php","_self")</script>';
                                break;
                        }
                    }
                   // $conn->close();
                    ?>


                </tbody>
            </table> 
            </div>
            <div class="box-footer">
                
            </div>
        </div>   
<div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Modal Header</h4>
                    </div>
                    <div class="modal-body">
                         <?php 
                         if (isset($_GET['action'])) {
                        switch ($_GET['action']) {
                            case 'show':
                                $id = $_GET["id"];
                                $get_pro = "select * from product_info where id = '" . $id . "'";
                                $run_get_pro = mysqli_query($conn, $get_pro);
                                $row_pro = mysqli_fetch_array($run_get_pro);
                                echo $get_pro;
                                // $product_id = $row_pro['id'];
                                $product_name = $row_pro['product_name'];
                                $product_desc = $row_pro['product_description'];
                                $product_image = $row_pro['product_logo_path'];
                                /* -- Modal */
                                echo "
                                    <span>$product_name</span>
                                    <span> $product_desc</span>
                                    <span><img src='$product_image' width='180' height='180'></span>
                                     ";
                                break;}}
                         ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
</div>
    <script type="text/javascript">
        $(document).ready(function () {
            //    $('#example').DataTable();
            $('#dataTable').dataTable({
                "bProcessing": true,
                "sAjaxSource": "Json/CustomerListJson.php",
                "sScrollX": "70%",
                "sScrollXInner": "110%",
                "bScrollCollapse": true,
                "bDestroy": true,
                "bJQueryUI": true
            });
        });
    </script>
<!-- /.content -->
<?php
include 'adminFooterMenu.php'
?>


<!-- echo "
        <div class='modal fade' id='myModal' role='dialog'>
        <div class='modal-dialog'>
         <div class='modal-header'>
          <button type='button'  class='close' data-dismiss='modal'>&times;</button>
          <h4 class= 'modal-title' >Product Details</h4>
         </div>
          <div class='modal-body'>
        <h3>$product_name</h3>
            <img src='$product_image' width='180' height='180'>
                </div>
                <div class='modal-footer'>
            <buttot  class='btn btn-default' data-dismiss='modal'>Close</button>
            </div>
        </div>
        </div>
    ";-->