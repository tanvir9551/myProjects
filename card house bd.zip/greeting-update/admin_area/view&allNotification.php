<?php
include '../admin_area/adminHeaderMenu.php';
?>



<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>



<div class="box box-warning"> 
    <div class="box-header btn-success">
        <h3 class="panel-title text-bold" style="color: #ffffff">Notification List</h3>
    </div>
    <div class="box-body">       
        <ul class="">
            <?php
            $get_pro = "select * from contact_us  ORDER BY create_date DESC";
            $reselt_pro = mysqli_query($conn, $get_pro);
            if ($reselt_pro->num_rows > 0) {
                while ($row = mysqli_fetch_array($reselt_pro)) {
                    $date = $row['create_date'];
                    $formateDate = date("d-m-Y", strtotime($date));
                    echo '<li style="display:block">Get message From ' . '&nbsp;' . ' <i class="fa fa-user text-green">&nbsp;&nbsp;</i><a href="view@notificationDetails.php?&id=' . $row['id'] . '">' . $row['person_email'] . '</a><span>&nbsp;&nbsp;</span>' . $formateDate . '</li>';


                }
            }
            ?>
        </ul>
    </div>
    <div class="box-footer">

    </div>
</div> 

<?php
include '../admin_area/adminFooterMenu.php';
?>