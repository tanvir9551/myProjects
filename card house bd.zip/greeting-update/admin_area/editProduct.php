<?php
//ob_start();
include 'adminHeaderMenu.php';


//    if (isset($_GET['id'])) {
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    if (isset($_POST['product_update'])) {
        $product_title = $_POST['productTitle'];
        $product_cat = $_POST['productCat'];
        $product_desc = $_POST['productDesc'];
        $product_image = $_FILES['productLogo']['name'];
        $tmp_dir = $_FILES['productLogo']['tmp_name'];
        $imgSize = $_FILES['productLogo']['size'];

        $sql = "select * from product_info where id ='" . $id . "'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        $upload_dir = '../images/product_img/'; // upload directory 

        if ($product_image) {
            //    if($product_image){


            $imgExt = strtolower(pathinfo($product_image, PATHINFO_EXTENSION)); // get image extension
            // valid image extensions
            $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
            // rename uploading image
            $userpic = rand(1000, 1000000) . "." . $imgExt;

            // allow valid image file formats
            if (in_array($imgExt, $valid_extensions)) {
                // Check file size '1MB'
                if ($imgSize < 1000000) {
                    unlink($upload_dir . $row['product_logo_nm']);
                    move_uploaded_file($tmp_dir, "$upload_dir$product_image");
                    $product_img_path = $upload_dir . $product_image;
//     move_uploaded_file($tmp_dir,$upload_dir.$userpic);
                } else {
                    $errMSG = "Sorry, your file is too large.";
                    echo '<h1 class="text-red" align="center">Sorry, your file is too large.</h1>';
                }
            } else {
                $errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                echo '<h1 class="text-red" align="center">Sorry, only JPG, JPEG, PNG & GIF files are allowed.</h1>';
            }
        } else {
            // if no image selected the old image remain as it is.
            $product_image = $row['product_logo_nm']; // old image from database
            $imgSize = $row['logo_size']; // old image from database
            $product_img_path = $row['product_logo_path']; // old image from database
            // return false;
        }
        if ($product_desc) {
            $product_desc = $_POST['productDesc'];
        } else {
            $product_desc = $row['product_description'];
        }
//        move_uploaded_file($product_image_tmp, "../images/product_img/$product_image");
//        $product_img_path = "../images/product_img/" . $product_image;
        // $sql = "insert into product_info(product_name,product_description,product_logo_nm,product_logo_path,entry_date) values('$product_title','$product_desc','$product_image','$product_img_path',now())";


        $sql = "UPDATE product_info SET 
        product_name='$product_title', product_description='$product_desc', product_logo_nm='$product_image',logo_size='$imgSize',product_logo_path='$product_img_path',product_cat='$product_cat',update_date = now() WHERE id='$id'"; // or die()

        $updated = mysqli_query($conn, $sql);
        if ($updated) {
            $msg = "Successfully Updated!!";
            echo '<script>window.open("productList.php","_self")</script>';
        }
    }
}  //update ends here
//ob_end_flush();
?>
<?php 
if (isset($_GET['action'])) {
                switch ($_GET['action']) {
                    case 'delete':
                        $id = $_GET["id"];
                        $get_pro = "select * from product_info where id= '" . $id . "'";
                        echo '<script>alert("'.$get_pro.'")</script>';
                        $run_get_pro = mysqli_query($conn, $get_pro);
                        $row_pro = mysqli_fetch_array($run_get_pro);

                        $path = $row_pro['product_logo_path'];
                        unlink($path);
                        $sql = "delete from product_info where id= '" . $id . "'";
                        $result = mysqli_query($conn, $sql);

//                        echo "<h3 class='text-green' align = 'center'>Record successfully deleted</h3>\n";
////                                echo "<h1 class="text-green" align="center">Deleted data successfully</h1>\n";
//                        echo '<script>window.open("productList.php","_self")</script>';
                        break;
                }
            }
?>
<div class="box box-warning">    
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "select * from product_info where id ='" . $id . "'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);

        //$fullname = $row['product_name'];
//    while ($row) {
        $productId = $row['id'];
        $productName = $row['product_name'];
        $productDescription = $row['product_description'];
//    echo $productDescription;
        $productimg = $row['product_logo_nm'];
        $product_cat_id = $row['product_cat'];
        ?>
        <form action="" enctype="multipart/form-data" method="post" class="form-horaizontal">
             <div class="box-header btn-success">
                <h3 class="panel-title text-bold" style="color: #ffffff">Edit Product</h3>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="form-group">
                        <label class="col-md-2 control-label">Product Title</label>
                        <div class="col-lg-8 col-xs-5">
                            <input type="text" name="productTitle" value="<?php echo $productName; ?>" class="form-control" id="">
                        </div>
                    </div>
                </div>&nbsp;
                <div class="row">
                    <div class="form-group">
                        <label class="col-md-2 control-label">Product Category</label>
                        <div class="col-lg-8 col-xs-5">
                            <select name="productCat" class="form-control">
                                 <option>Select Product Category</option>
                                <?php
                                $options = "select id,category_title from product_category";
                                $optionIds = mysqli_query($conn, $options);
                                $existing_id = $product_cat_id;
                                while ($row_optionIds = mysqli_fetch_array($optionIds)) {
                                    // Check if the existing id is the same as the current id we are displaying
                                    // If it is, set the selected attribute
                                    if ($existing_id == $row_optionIds['id'])
                                        echo "<option selected='selected' value='" . $row_optionIds['id'] . "'>" . $row_optionIds['category_title'] . "</option>";
                                    else
                                        echo "<option value='" . $row_optionIds['id'] . "'>" . $row_optionIds['category_title'] . "</option>";
                                }
                                ?>
                            </select>

                        </div>
                    </div>
                </div>&nbsp;
                <div class="row">
                    <div class="form-group">
                        <label class="col-md-2 control-label">Product Logo</label>
                        <div class="col-lg-8 col-xs-5">
                            <img src="<?php echo $row['product_logo_path']; ?>" class="img-rounded" width="150px" height="150px" />
                        </div>
                    </div>
                </div>&nbsp;
                <div class="row">
                    <div class="form-group">
                        <label class="col-md-2 control-label">Product Logo</label>
                        <div class="col-lg-8 col-xs-5">
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <span class="btn btn-warning btn-file">
                                        Browse  &hellip;
                                        <input class="input-group fileName" type="file" id="picName" name="productLogo" accept="image/*" />
                                        <input type="file" id="picName" name="productLogo" value="<?php echo $productimg; ?>"
                                               class="fileName">
                                    </span>
                                </span>
                                <input type="text" class="form-control tf" readonly="readonly" id="productLogos"
                                       name="productLogo" value="<?php echo $productimg; ?>"
                                       placeholder ="Browse your file" class="form-control input-sm">

                            </div>
                        </div>                                                        
                    </div>
                </div>&nbsp;
                <div class="row"> 
                    <div class="form-group">
                        <label class="col-md-2 control-label">Product Description</label>                                       
                        <div class="col-lg-8 col-xs-5">
                            <textarea  name="productDesc"  value="" class="" id=""><?php echo $productDescription; ?></textarea>
                        </div>
                    </div>
                </div>&nbsp;
                <div class="row">
                    <div class="col-lg-8 col-xs-5">
                        <div class="form-group">
                            <label class="col-md-2 control-label"></label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer" style="margin-left: 35%">
                <button type="submit" name="product_update" class="btn btn-success p-r-5" id="submit"><i class="fa fa-save"></i> Edit Product</button>
                <!--<button type="reset" class="btn btn-danger" ><i class='fa fa-fw fa-eraser'></i></i> Delete Product</button>-->
                <a href="editProduct.php?action=delete&id='<?php echo $productId; ?>' " class='btn btn-danger'> Delete Product <i class='fa fa-fw fa-eraser'></i></a>
            </div><!-- /.box-footer -->
        </form>
        <?php
    }
//}     
    ?>
    <!-- jQuery 2.2.3 -->
    <script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
    <script src="//cdn.ckeditor.com/4.5.6/full/ckeditor.js"></script>
    <!--<script src="//cdn.ckeditor.com/4.5.10/standard/ckeditor.js"></script>-->
    <!--<script src="//cdn.ckeditor.com/4.5.10/basic/ckeditor.js"></script>-->
    <script>
        $(document).ready(function () {
            CKEDITOR.replace('productDesc');
            $(document).on('change', '#picName', function () {
                var value = this.value;
                if (value) {
                    $("#productLogos").val(value);
                }
            });
        });
    </script>
</div>

<?php
include 'adminFooterMenu.php';   

            //$conn->close();
    
?>
