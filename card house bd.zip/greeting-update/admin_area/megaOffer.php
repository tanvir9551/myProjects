<!DOCTYPE HTML>
<?php
include 'adminHeaderMenu.php';
?>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <title>Add Mega Offer</title>
        <script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
    </head>
    <body class="productCatBody">

        <div class="box box-warning ">
             <div class="box-header btn-success">
                        <h3 class="panel-title text-bold" style="color: #ffffff">Create New Mega Offer</h3>
                    </div>
            <form action="megaOffer.php" enctype="multipart/form-data" method="post">
                <div class="box-body">                   
                    <div class="row">
                        <div class="form-group">
                            <label class="col-md-2 control-label">Mega Offer</label>
                            <div class="col-lg-8">
                                <input type="text" name="productCatName" value="" class="form-control" id="">
                            </div>
                        </div>
                    </div>&nbsp;
              
                    <!--            </div>
                                <div class="box-footer">-->
                    <div class="box-footer" style="margin-left: 35%">
                        <button type="submit" name="product_cat_submit" class="btn btn-foursquare p-r-5" id="submit"><i class="fa fa-save"></i> Save Offer</button>
                        <button type="reset" class="btn btn-info " ><i class="fa fa-refresh"></i> Reset Offer</button>
                    </div>
                </div><!-- /.box-footer -->
                <!--<input type="submit" name="product_cat_submit"  value="Save" class="" id="">-->


<!--        <table style="background-color: chartreuse;" class="productTable" align="center" border="2" width="60%">
   <thead>
       <tr>
           <td align="center" colspan="7">Add New Product Category</td>  
       </tr>
   </thead>
   <tbody>
       <tr>
           <td>Product Category:</td>
           <td><input type="text" name="productCatName" value="" class="form-control" id=""></td>
       </tr> 
       <tr>
           <td>Keyword:</td>
           <td><input type="text" name="keyword" value="" class="form-control" id=""></td>
       </tr> 
       <tr >                    
           <td align="center" colspan="2"><input type="submit" name="productCatSave"  value="product_submitSave" class="" id=""></td>
       </tr>
   </tbody>
   <tr>
       <td align="center" colspan="7"><input type="submit" name="product_submit"  value="Save" class="" id=""></td>
   </tr>
</table>-->
            </form>
        </div>
    </body>
</html>

<?php
if (isset($_POST['product_cat_submit'])) {
    $product_cat = $_POST['productCatName'];
    $sql = "insert into mega_offer (category_title) values('$product_cat')";

    $insert_pro = mysqli_query($conn, $sql);
    //$insert_pro = mysqli_query($conn, $sql);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    if ($insert_pro) {
        echo '<script>alert("Data save successfully!!!!!")</script>';
        echo '<script>window.open("insert_product_cat.php","_self")</script>'; //open targated page
    } else {
        echo 'oh!sorry!!';
    }
}
include 'adminFooterMenu.php'
?>
