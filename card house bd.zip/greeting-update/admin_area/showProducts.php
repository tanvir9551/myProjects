<?php
include '../function/function.php';
include 'adminHeaderMenu.php';
//include 'headerMenuIndex.php';
?>

<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>


        <div class="box box-warning">
            <div class="box-body">
                <div class="" id="content_area">
                <!---->
                <div class="product_box">
                    <?php
                    global $conn;
    $get_pro = "select * from product_info";
    $run_get_pro = mysqli_query($conn, $get_pro);
    while ($row_pro = mysqli_fetch_array($run_get_pro)) {
		?>
		<?php
        $product_id = $row_pro['id'];
        $product_name = $row_pro['product_name'];
        $product_desc = $row_pro['product_description'];
        $product_image = $row_pro['product_logo_nm'];

        echo "
                <div class='col-md-4'>
                <img src='../images/product_img/$product_image' width='180' height='180' alt='No image found' style='background-color: #000' class='img-responsive'>
               <p> <h6 class='text-yellow'>$product_name</h6>
                <a href='../showProducts.php?&id= " . $product_id . " target='_blank'>Read More...</a></p>                
             </div>
                            
";
                    ?>
                </div>
            </div>
            </div>
        </div>
<?php
include 'adminFooterMenu.php'
?>