<?php
//include './includes/db.php';
include 'adminHeaderMenu.php';
?>

<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>


<div class="box box-warning">    
    <?php
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sqlUpdate = "UPDATE contact_us SET 
        is_new='" . FALSE . "' WHERE id='$id'"; // or die()
        mysqli_query($conn, $sqlUpdate);
        $sql = "select * from contact_us where id ='" . $id . "'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
        $personName = $row['person_name'];
        $personEmail = $row['person_email'];
        $personPhone = $row['person_phone'];
        $personMessage = $row['person_message'];
        $notificationDate = $row['create_date'];
        $formateDate = date("d-m-Y", strtotime($notificationDate));
        ?>     

        <!--        <div class="box-warning">-->
        <div class="box-header btn-success">
            <h3 class="panel-title">Notification Details</h3>
        </div>
        <div class="box-body">
            <!--<div class="row">-->
            <table class="table table-hover table-responsive table-striped">
                <tr>
                    <th>Name</th>
                    <td><?php echo $personName; ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo $personEmail; ?></td>
                </tr>
                <tr>
                    <th>Phone</th>
                    <td><?php echo $personPhone; ?></td>
                </tr>
                <tr>
                    <th>Message</th>
                    <td><?php echo $personMessage; ?></td>
                </tr>
                <tr>
                    <th>Message Send Date</th>
                    <td><?php echo $formateDate; ?></td>
                </tr>
            </table>
            <!--</div>-->
        </div>
        <div class="box-footer">

        </div>
        <?php
    }
    ?>
</div>



<?php
include '../admin_area/adminFooterMenu.php';
?>