<?php
include 'adminHeaderMenu.php';
?>

<!-- Main content -->
<!-- data table 1.10.12 cdn file -->
<!--<link href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/css/dataTables.bootstrap.min.css" rel="stylesheet" />-->
<link href="../assets/datatable/dataTables.bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
<!-- Bootstrap 3.3.6 -->
<script src="../plugins/bootstrap/bootstrap.min.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- data table 1.10.12-->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.12/js/dataTables.bootstrap.min.js"></script>-->
<script src="../plugins/datatable/dataTables.bootstrap.min.js"></script>

<div class="box box-warning">
    <?php
    if (isset($_POST['sav'])) {
        $fNames = $_POST['fullName'];
        $uNames = $_POST['userName'];
        $uPasss = $_POST['password'];
        $email = $_POST['email'];
        $cellPhone = $_POST['contactNo'];
		$usertype = $_POST['select'];
       // $isAdmins = isset($_POST["isAdmin"]) ? $_POST["isAdmin"] : 0;
        if ($uNames && $uPasss) {
            $sql = "select user_name from user_info where user_name = '" . $uNames . "'";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_array($result);
            $userName = $row['user_name'];
            if ($userName) {
                echo '<h1 class="text-red" align="center">Duplicate user name found! Please try another one</h1>';
            } else if (!$userName) {
                $sql = "insert into user_info(full_name,user_name,password,contact_no,email,is_admin,created_date)
                    values('$fNames','$uNames','$uPasss','$cellPhone','$email','$usertype',now())";

                $insert_pro = mysqli_query($conn, $sql);
                if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                }
                if ($insert_pro) {
                    echo '<h1 class="text-green" align="center">Registration Process successfully completed!!!!!</h1>';
//                echo '<script>alert("Your Registration Process successfully completed!!!!!")</script>';
                    echo '<script>window.open("userSignUpPage.php","_blank")</script>'; //open targated page
                } else {
                    echo '<h1 class="text-red" align="center">oh!sorry!!</h1>';
                }
            }
        } else {
            echo '<h1 class="text-red" align="center">Oh!User name & password is required!!</h1>';
        }
    }
    ?>
    <form action="userSignUpPage.php" enctype="multipart/form-data" method="post" class="form-horaizontal" role="form">

        <div class="box-header btn-success">
            <h3 class="panel-title text-bold" style="color: #ffffff">Create User</h3>
        </div>
        <div class="box-body">
            <div class="row">
                <div class="form-group">
                    <label class="control-label col-md-2">Full Name</label>
                    <div class="col-xs-6 col-sm-12 col-md-6">
                        <input type="text" name="fullName" id="fullName" class="form-control input-sm" placeholder="Full Name">
                    </div>
                </div>
            </div>&nbsp;
            <div class="row">
                <div class="form-group">
                    <label class="control-label col-md-2">contact No</label>
                    <div class="col-xs-6 col-sm-12 col-md-6">
                        <input type="text" name="contactNo" id="contactNo" class="form-control input-sm" placeholder="contact No">
                    </div>
                </div>
            </div>&nbsp;
            <div class="row">
                <div class="form-group">
                    <label class="control-label col-md-2">Email Address</label>
                    <div class="col-xs-6 col-sm-12 col-md-6">
                        <input type="email" name="email" id="email" class="form-control input-sm" placeholder="Email Address">
                    </div>
                </div>
            </div>&nbsp;
            <div class="row">
                <div class="form-group">
                    <label class="control-label col-md-2">User Name</label>
                    <div class="col-xs-6 col-sm-12 col-md-6">
                        <input type="text" name="userName" id="userName" class="form-control input-sm" placeholder="User Name">
                    </div>
                </div>
            </div>&nbsp;
            <div class="row">
                <div class="form-group">
                    <label class="control-label col-md-2">Password</label>
                    <div class="col-xs-6 col-sm-12 col-md-6">
                        <input type="password" name="password" id="password" class="form-control input-sm" placeholder="Password">
                    </div>
                </div>
            </div>&nbsp;
            <div class="row">
                <div class="col-xs-6 col-sm-12 col-md-6">
                    <div class="form-group">
                        <div class="col-md-2" style="margin-left: -12px">
                            <!--<input type="checkbox" name="isAdmin" value="1">-->
							<select name="select">
								<option value="admin">Admin</option>
								<option value="staff">Staff</option>
								<option value="print">Printing & Delivery</option>
							</select>
                        </div>                                            
                        <!--<label class="" style="color: #4B6170;margin-left: -15px ">Is Admin</label>-->
						
                    </div>
                </div>
            </div>
        </div>
        <div class="box-footer" style="margin-left: 35%">
            <button type="submit" name="sav" class="btn btn-foursquare p-r-5" id="submit"><i class="fa fa-save"></i> Create User</button>
            <button type="reset" class="btn btn-info" ><i class="fa fa-refresh"></i> Reset User</button>

        </div><!-- /.box-footer -->
        <!---->

    </form>
</div>






<?php
include 'adminFooterMenu.php'
?>