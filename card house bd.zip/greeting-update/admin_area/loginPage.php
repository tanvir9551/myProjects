<!DOCTYPE html>
<?php
//session_start([
//    'cookie_lifetime' => 86400,
//    'read_and_close'  => true,
//]);
include ('includes/db.php');

// session_close();
if (!isset($_SESSION)) {
    session_start();
//echo'session start';
}
?>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <!--     !**cdn**!
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        -->

        <link href="../assets/bootstrap/bootstrap.css" rel="stylesheet" />
        <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        <link href="../assets/pace/pace-theme-big-counter.css" rel="stylesheet" />
        <link href="../assets/css/style.css" rel="stylesheet" />
        <link href="../assets/css/main-style.css" rel="stylesheet" />

    </head>
    <body class="body-Login-back">

        <div class="container">

            <div class="row">
                <div class="col-md-4 col-md-offset-4 text-center logo-margin ">
<!--                    <img src="assets/img/logo.png" alt=""/>-->
                </div>
                <div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">                  
                        <div class="panel-heading">
                            <h3 class="panel-title">Please Sign In</h3>
                        </div>
                        <div class="panel-body">
                            <form role="form" action="loginPage.php" method="post">
                                <fieldset>
                                    <div class="form-group">
                                        <!--                                        <div class="input-group">
                                                                                    <span class="input-group-addon"></span>                                       -->
                                        <input type="text" name="userName" id="userName" class="form-control input-sm" placeholder="User Name" autofocus>                                       
                                        <!--</div>-->
                                    </div>
                                    <div class="form-group">
                                        <!--                                        <div class="input-group">
                                                                                    <span class="fa fa-key fa-lg fa-fw"></span>   -->
                                        <input type="password" name="password" id="password" class="form-control input-sm" placeholder="Password">
                                        <!--                                        </div>-->
                                    </div>
                                    <input type="submit" name="sub" value="Login" class="btn btn-lg btn-success btn-block">
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Core Scripts - Include with every page -->
        <script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
        <script src="../plugins/bootstrap/bootstrap.min.js"></script>
        <script src="../plugins/metisMenu/jquery.metisMenu.js"></script> 
    </body>
    <?php
    if (!isset($_SESSION)) {
        session_start();
    }
    if (isset($_POST['sub'])) {
        if ($_SESSION["username"]) {
            echo "You are already logged in, " . $_SESSION['username'];
            unset($_SESSION);
            //session_destroy();
            exit("");
        }

        $loggedIn = false;
        $userName = $_POST["userName"];
        $userPass = $_POST["password"];

        if ($userName && $userPass) {
            // User Entered fields
            $query = "SELECT user_name FROM user_info WHERE user_name = '$userName' AND password = '$userPass'"; // AND password = $userPass";

            $result = mysqli_query($conn, $query);
            $row = mysqli_fetch_array($result);

            if (!$row) {
                echo "<div>";
                echo "No existing user or wrong password.";
                echo "</div>";
            } else
                $loggedIn = true;
        }

        if (!$loggedIn) {
            echo '<script>alert("Sorry invalid user name or password.Please try again")</script>';
        } else {
//            echo "<div>";
            //echo "You have been logged in as $userName!";
//            echo '<script>alert("You have been logged in as"+ $userName!)</script>';
//
//            echo "</div>";
            $_SESSION["username"] = $userName;
//            $_SESSION["fullname"] = $row['full_name'];
            echo '<script>window.open("adminLandingPage.php","_self")</script>';
//                echo '<script>window.open("../index.php","_self")</script>';
        }
    }
    ?>
</html>
