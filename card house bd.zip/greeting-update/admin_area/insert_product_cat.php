<!DOCTYPE HTML>
<?php
include 'adminHeaderMenu.php';
?>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <title>Add Product Category</title>
        <script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
    </head>
    <body class="productCatBody">

        <div class="box box-warning ">
             <div class="box-header btn-success">
                        <h3 class="panel-title text-bold" style="color: #ffffff">Create New Product category</h3>
                    </div>
            <form action="insert_product_cat.php" enctype="multipart/form-data" method="post">
                <div class="box-body">                   
                    <div class="row">
                        <div class="form-group">
                            <label class="col-md-2 control-label">Product Category Name</label>
                            <div class="col-lg-8">
                                <input type="text" name="productCatName" value="" class="form-control" id="">
                            </div>
                        </div>
                    </div>&nbsp;
                    <div class="row">
                        <div class="form-group">
                            <label class="col-md-2  control-label">Keyword</label>
                            <div class="col-lg-8">
                                <select name="keyword">
    <optgroup label="Web Application Icons">
        <option value="fa fa-adjust">icon-adjust</option>
        <option value="fa fa-asterisk">icon-asterisk</option>
        <option value="fa fa-ban-circle">icon-ban-circle</option>
        <option value="fa fa-bar-chart">icon-bar-chart</option>
        <option value="fa fa-barcode">icon-barcode</option>
        <option value="fa fa-beaker">icon-beaker</option>
        <option value="fa fa-beer">icon-beer</option>
        <option value="fa fa-bell">icon-bell</option>
        <option value="fa fa-bell-alt">icon-bell-alt</option>
        <option value="fa fa-bolt">icon-bolt</option>
        <option value="fa fa-book">icon-book</option>
        <option value="fa fa-bookmark">icon-bookmark</option>
        <option value="fa fa-bookmark-empty">icon-bookmark-empty</option>
        <option value="fa fa-briefcase">icon-briefcase</option>
        <option value="fa fa-bullhorn">icon-bullhorn</option>
        <option value="fa fa-calendar">icon-calendar</option>
        <option value="fa fa-camera">icon-camera</option>
        <option value="fa fa-camera-retro">icon-camera-retro</option>
        <option value="fa fa-certificate">icon-certificate</option>
        <option value="fa fa-check">icon-check</option>
        <option value="fa fa-check-empty">icon-check-empty</option>
        <option value="fa fa-circle">icon-circle</option>
        <option value="fa fa-circle-blank">icon-circle-blank</option>
        <option value="fa fa-cloud">icon-cloud</option>
        <option value="fa fa-cloud-download">icon-cloud-download</option>
        <option value="fa fa-cloud-upload">icon-cloud-upload</option>
        <option value="fa fa-coffee">icon-coffee</option>
        <option value="fa fa-cog">icon-cog</option>
        <option value="fa fa-cogs">icon-cogs</option>
        <option value="fa fa-comment">icon-comment</option>
        <option value="fa fa-comment-alt">icon-comment-alt</option>
        <option value="fa fa-comments">icon-comments</option>
        <option value="fa fa-comments-alt">icon-comments-alt</option>
        <option value="fa fa-credit-card">icon-credit-card</option>
        <option value="fa fa-dashboard">icon-dashboard</option>
        <option value="fa fa-desktop">icon-desktop</option>
        <option value="fa fa-download">icon-download</option>
        <option value="fa fa-download-alt">icon-download-alt</option>
        <option value="fa fa-edit">icon-edit</option>
        <option value="fa fa-envelope">icon-envelope</option>
        <option value="fa fa-envelope-alt">icon-envelope-alt</option>
        <option value="fa fa-exchange">icon-exchange</option>
        <option value="fa fa-exclamation-sign">icon-exclamation-sign</option>
        <option value="fa fa-external-link">icon-external-link</option>
        <option value="fa fa-eye-close">icon-eye-close</option>
        <option value="fa fa-eye-open">icon-eye-open</option>
        <option value="fa fa-facetime-video">icon-facetime-video</option>
        <option value="fa fa-fighter-jet">icon-fighter-jet</option>
        <option value="fa fa-film">icon-film</option>
        <option value="fa fa-filter">icon-filter</option>
        <option value="fa fa-fire">icon-fire</option>
        <option value="fa fa-flag">icon-flag</option>
        <option value="fa fa-folder-close">icon-folder-close</option>
        <option value="fa fa-folder-open">icon-folder-open</option>
        <option value="fa fa-folder-close-alt">icon-folder-close-alt</option>
        <option value="fa fa-folder-open-alt">icon-folder-open-alt</option>
        <option value="fa fa-food">icon-food</option>
        <option value="fa fa-gift">icon-gift</option>
        <option value="fa fa-glass">icon-glass</option>
        <option value="fa fa-globe">icon-globe</option>
        <option value="fa fa-group">icon-group</option>
        <option value="fa fa-hdd">icon-hdd</option>
        <option value="fa fa-headphones">icon-headphones</option>
        <option value="fa fa-heart">icon-heart</option>
        <option value="fa fa-heart-empty">icon-heart-empty</option>
        <option value="fa fa-home">icon-home</option>
        <option value="fa fa-inbox">icon-inbox</option>
        <option value="fa fa-info-sign">icon-info-sign</option>
        <option value="fa fa-key">icon-key</option>
        <option value="fa fa-leaf">icon-leaf</option>
        <option value="fa fa-laptop">icon-laptop</option>
        <option value="fa fa-legal">icon-legal</option>
        <option value="fa fa-lemon">icon-lemon</option>
        <option value="fa fa-lightbulb">icon-lightbulb</option>
        <option value="fa fa-lock">icon-lock</option>
        <option value="fa fa-unlock">icon-unlock</option>
        <option value="fa fa-magic">icon-magic</option>
        <option value="fa fa-magnet">icon-magnet</option>
        <option value="fa fa-map-marker">icon-map-marker</option>
        <option value="fa fa-minus">icon-minus</option>
        <option value="fa fa-minus-sign">icon-minus-sign</option>
        <option value="fa fa-mobile-phone">icon-mobile-phone</option>
        <option value="fa fa-money">icon-money</option>
        <option value="fa fa-move">icon-move</option>
        <option value="fa fa-music">icon-music</option>
        <option value="fa fa-off">icon-off</option>
        <option value="fa fa-ok">icon-ok</option>
        <option value="fa fa-ok-circle">icon-ok-circle</option>
        <option value="fa fa-ok-sign">icon-ok-sign</option>
        <option value="fa fa-pencil">icon-pencil</option>
        <option value="fa fa-picture">icon-picture</option>
        <option value="fa fa-plane">icon-plane</option>
        <option value="fa fa-plus">icon-plus</option>
        <option value="fa fa-plus-sign">icon-plus-sign</option>
        <option value="fa fa-print">icon-print</option>
        <option value="fa fa-pushpin">icon-pushpin</option>
        <option value="fa fa-qrcode">icon-qrcode</option>
        <option value="fa fa-question-sign">icon-question-sign</option>
        <option value="fa fa-quote-left">icon-quote-left</option>
        <option value="fa fa-quote-right">icon-quote-right</option>
        <option value="fa fa-random">icon-random</option>
        <option value="fa fa-refresh">icon-refresh</option>
        <option value="fa fa-remove">icon-remove</option>
        <option value="fa fa-remove-circle">icon-remove-circle</option>
        <option value="fa fa-remove-sign">icon-remove-sign</option>
        <option value="fa fa-reorder">icon-reorder</option>
        <option value="fa fa-reply">icon-reply</option>
        <option value="fa fa-resize-horizontal">icon-resize-horizontal</option>
        <option value="fa fa-resize-vertical">icon-resize-vertical</option>
        <option value="fa fa-retweet">icon-retweet</option>
        <option value="fa fa-road">icon-road</option>
        <option value="fa fa-rss">icon-rss</option>
        <option value="fa fa-screenshot">icon-screenshot</option>
        <option value="fa fa-search">icon-search</option>
        <option value="fa fa-share">icon-share</option>
        <option value="fa fa-share-alt">icon-share-alt</option>
        <option value="fa fa-shopping-cart">icon-shopping-cart</option>
        <option value="fa fa-signal">icon-signal</option>
        <option value="fa fa-signin">icon-signin</option>
        <option value="fa fa-signout">icon-signout</option>
        <option value="fa fa-sitemap">icon-sitemap</option>
        <option value="fa fa-sort">icon-sort</option>
        <option value="fa fa-sort-down">icon-sort-down</option>
        <option value="fa fa-sort-up">icon-sort-up</option>
        <option value="fa fa-spinner">icon-spinner</option>
        <option value="fa fa-star">icon-star</option>
        <option value="fa fa-star-empty">icon-star-empty</option>
        <option value="fa fa-star-half">icon-star-half</option>
        <option value="fa fa-tablet">icon-tablet</option>
        <option value="fa fa-tag">icon-tag</option>
        <option value="fa fa-tags">icon-tags</option>
        <option value="fa fa-tasks">icon-tasks</option>
        <option value="fa fa-thumbs-down">icon-thumbs-down</option>
        <option value="fa fa-thumbs-up">icon-thumbs-up</option>
        <option value="fa fa-time">icon-time</option>
        <option value="fa fa-tint">icon-tint</option>
        <option value="fa fa-trash">icon-trash</option>
        <option value="fa fa-trophy">icon-trophy</option>
        <option value="fa fa-truck">icon-truck</option>
        <option value="fa fa-umbrella">icon-umbrella</option>
        <option value="fa fa-upload">icon-upload</option>
        <option value="fa fa-upload-alt">icon-upload-alt</option>
        <option value="fa fa-user">icon-user</option>
        <option value="fa fa-user-md">icon-user-md</option>
        <option value="fa fa-volume-off">icon-volume-off</option>
        <option value="fa fa-volume-down">icon-volume-down</option>
        <option value="fa fa-volume-up">icon-volume-up</option>
        <option value="fa fa-warning-sign">icon-warning-sign</option>
        <option value="fa fa-wrench">icon-wrench</option>
        <option value="fa fa-zoom-in">icon-zoom-in</option>
        <option value="fa fa-zoom-out">icon-zoom-out</option>
    <optgroup label="Text Editor Icons">
        <option value="fa fa-file">icon-file</option>
        <option value="fa fa-file-alt">icon-file-alt</option>
        <option value="fa fa-cut">icon-cut</option>
        <option value="fa fa-copy">icon-copy</option>
        <option value="fa fa-paste">icon-paste</option>
        <option value="fa fa-save">icon-save</option>
        <option value="fa fa-undo">icon-undo</option>
        <option value="fa fa-repeat">icon-repeat</option>
        <option value="fa fa-text-height">icon-text-height</option>
        <option value="fa fa-text-width">icon-text-width</option>
        <option value="fa fa-align-left">icon-align-left</option>
        <option value="fa fa-align-center">icon-align-center</option>
        <option value="fa fa-align-right">icon-align-right</option>
        <option value="fa fa-align-justify">icon-align-justify</option>
        <option value="fa fa-indent-left">icon-indent-left</option>
        <option value="fa fa-indent-right">icon-indent-right</option>
        <option value="fa fa-font">icon-font</option>
        <option value="fa fa-bold">icon-bold</option>
        <option value="fa fa-italic">icon-italic</option>
        <option value="fa fa-strikethrough">icon-strikethrough</option>
        <option value="fa fa-underline">icon-underline</option>
        <option value="fa fa-link">icon-link</option>
        <option value="fa fa-paper-clip">icon-paper-clip</option>
        <option value="fa fa-columns">icon-columns</option>
        <option value="fa fa-table">icon-table</option>
        <option value="fa fa-th-large">icon-th-large</option>
        <option value="fa fa-th">icon-th</option>
        <option value="fa fa-th-list">icon-th-list</option>
        <option value="fa fa-list">icon-list</option>
        <option value="fa fa-list-ol">icon-list-ol</option>
        <option value="fa fa-list-ul">icon-list-ul</option>
        <option value="fa fa-list-alt">icon-list-alt</option>
    <optgroup label="Directional Icons">
        <option value="fa fa-angle-left">icon-angle-left</option>
        <option value="fa fa-angle-right">icon-angle-right</option>
        <option value="fa fa-angle-up">icon-angle-up</option>
        <option value="fa fa-angle-down">icon-angle-down</option>
        <option value="fa fa-arrow-down">icon-arrow-down</option>
        <option value="fa fa-arrow-left">icon-arrow-left</option>
        <option value="fa fa-arrow-right">icon-arrow-right</option>
        <option value="fa fa-arrow-up">icon-arrow-up</option>
        <option value="fa fa-caret-down">icon-caret-down</option>
        <option value="fa fa-caret-left">icon-caret-left</option>
        <option value="fa fa-caret-right">icon-caret-right</option>
        <option value="fa fa-caret-up">icon-caret-up</option>
        <option value="fa fa-chevron-down">icon-chevron-down</option>
        <option value="fa fa-chevron-left">icon-chevron-left</option>
        <option value="fa fa-chevron-right">icon-chevron-right</option>
        <option value="fa fa-chevron-up">icon-chevron-up</option>
        <option value="fa fa-circle-arrow-down">icon-circle-arrow-down</option>
        <option value="fa fa-circle-arrow-left">icon-circle-arrow-left</option>
        <option value="fa fa-circle-arrow-right">icon-circle-arrow-right</option>
        <option value="fa fa-circle-arrow-up">icon-circle-arrow-up</option>
        <option value="fa fa-double-angle-left">icon-double-angle-left</option>
        <option value="fa fa-double-angle-right">icon-double-angle-right</option>
        <option value="fa fa-double-angle-up">icon-double-angle-up</option>
        <option value="fa fa-double-angle-down">icon-double-angle-down</option>
        <option value="fa fa-hand-down">icon-hand-down</option>
        <option value="fa fa-hand-left">icon-hand-left</option>
        <option value="fa fa-hand-right">icon-hand-right</option>
        <option value="fa fa-hand-up">icon-hand-up</option>
        <option value="fa fa-circle">icon-circle</option>
        <option value="fa fa-circle-blank">icon-circle-blank</option>
    <optgroup label="Video Player Icons">
        <option value="fa fa-play-circle">icon-play-circle</option>
        <option value="fa fa-play">icon-play</option>
        <option value="fa fa-pause">icon-pause</option>
        <option value="fa fa-stop">icon-stop</option>
        <option value="fa fa-step-backward">icon-step-backward</option>
        <option value="fa fa-fast-backward">icon-fast-backward</option>
        <option value="fa fa-backward">icon-backward</option>
        <option value="fa fa-forward">icon-forward</option>
        <option value="fa fa-fast-forward">icon-fast-forward</option>
        <option value="fa fa-step-forward">icon-step-forward</option>
        <option value="fa fa-eject">icon-eject</option>
        <option value="fa fa-fullscreen">icon-fullscreen</option>
        <option value="fa fa-resize-full">icon-resize-full</option>
        <option value="fa fa-resize-small">icon-resize-small</option>
    <optgroup label="Social Icons">
        <option value="fa fa-phone">icon-phone</option>
        <option value="fa fa-phone-sign">icon-phone-sign</option>
        <option value="fa fa-facebook">icon-facebook</option>
        <option value="fa fa-facebook-sign">icon-facebook-sign</option>
        <option value="fa fa-twitter">icon-twitter</option>
        <option value="fa fa-twitter-sign">icon-twitter-sign</option>
        <option value="fa fa-github">icon-github</option>
        <option value="fa fa-github-alt">icon-github-alt</option>
        <option value="fa fa-github-sign">icon-github-sign</option>
        <option value="fa fa-linkedin">icon-linkedin</option>
        <option value="fa fa-linkedin-sign">icon-linkedin-sign</option>
        <option value="fa fa-pinterest">icon-pinterest</option>
        <option value="fa fa-pinterest-sign">icon-pinterest-sign</option>
        <option value="fa fa-google-plus">icon-google-plus</option>
        <option value="fa fa-google-plus-sign">icon-google-plus-sign</option>
        <option value="fa fa-sign-blank">icon-sign-blank</option>
    <optgroup label="Medical Icons">
        <option value="fa fa-ambulance">icon-ambulance</option>
        <option value="fa fa-beaker">icon-beaker</option>
        <option value="fa fa-h-sign">icon-h-sign</option>
        <option value="fa fa-hospital">icon-hospital</option>
        <option value="fa fa-medkit">icon-medkit</option>
        <option value="fa fa-plus-sign-alt">icon-plus-sign-alt</option>
        <option value="fa fa-stethoscope">icon-stethoscope</option>
        <option value="fa fa-user-md">icon-user-md</option>
</select>
                            </div>
                        </div>
                    </div>&nbsp;
					  <div class="row">
                        <div class="form-group">
                            <label class="col-md-2 control-label">Category Icon Color</label>
                            <div class="col-lg-8">
                                <select name="catIconColor">
								<option value="#F20F0F">Red</option>
								</select>
								
                            </div>
                        </div>
                    </div>&nbsp;
                    <!--            </div>
                                <div class="box-footer">-->
                    <div class="box-footer" style="margin-left: 35%">
                        <button type="submit" name="product_cat_submit" class="btn btn-foursquare p-r-5" id="submit"><i class="fa fa-save"></i> Save Product</button>
                        <button type="reset" class="btn btn-info " ><i class="fa fa-refresh"></i> Reset Product</button>
                    </div>
                </div><!-- /.box-footer -->
                <!--<input type="submit" name="product_cat_submit"  value="Save" class="" id="">-->


<!--        <table style="background-color: chartreuse;" class="productTable" align="center" border="2" width="60%">
   <thead>
       <tr>
           <td align="center" colspan="7">Add New Product Category</td>  
       </tr>
   </thead>
   <tbody>
       <tr>
           <td>Product Category:</td>
           <td><input type="text" name="productCatName" value="" class="form-control" id=""></td>
       </tr> 
       <tr>
           <td>Keyword:</td>
           <td><input type="text" name="keyword" value="" class="form-control" id=""></td>
       </tr> 
       <tr >                    
           <td align="center" colspan="2"><input type="submit" name="productCatSave"  value="product_submitSave" class="" id=""></td>
       </tr>
   </tbody>
   <tr>
       <td align="center" colspan="7"><input type="submit" name="product_submit"  value="Save" class="" id=""></td>
   </tr>
</table>-->
            </form>
        </div>
    </body>
</html>

<?php
if (isset($_POST['product_cat_submit'])) {
    $product_cat = $_POST['productCatName'];
    $product_keyword = $_POST['keyword'];
	$category_color = $_POST['catIconColor'];
    $sql = "insert into product_category (category_title,category_keyword,category_color) values('$product_cat','$product_keyword','$category_color')";

    $insert_pro = mysqli_query($conn, $sql);
	var_dump($insert_pro);
    //$insert_pro = mysqli_query($conn, $sql);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    if ($insert_pro) {
        echo '<script>alert("Data save successfully!!!!!")</script>';
        echo '<script>window.open("insert_product_cat.php","_self")</script>'; //open targated page
    } else {
        echo 'oh!sorry!!';
    }
}
include 'adminFooterMenu.php'
?>
