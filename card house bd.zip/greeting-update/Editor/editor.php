<?php include '..\admin_area\includes\db.php'; ?>


<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<script type='text/javascript' src='js/jquery.min.js'></script>
<script src="js/kinetic-v3.9.3.js"></script>
<script type="text/javascript" src ="../js/bootstrap.js"></script>

<!--header.php js and css-->


<title>Online Greeting Card</title>
<meta name="author" content="" />
<link href="css/layout.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="css/menu.css" type="text/css" media="screen" />
<!-- Menu -->
<!--[if lt IE 9]>
<link rel="stylesheet" type="text/css" href="css/ie/ie.css" />
<![endif]-->
<link rel="stylesheet" href="styles/global.css" type="text/css" media="screen" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/mobile.js"></script>
<script type="text/javascript" src="js/form.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#spinner").bind("ajaxSend", function() {
		$(this).show();
	}).bind("ajaxStop", function() {
		$(this).hide();
	}).bind("ajaxError", function() {
		$(this).hide();
	});

     });
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-5918573-53']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!--header-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
    function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" /> 
<link href="../css/menu.css" rel="stylesheet" type="text/css" media="all" /> <!-- menu style --> 
<link href="../css/ken-burns.css" rel="stylesheet" type="text/css" media="all" /> <!-- banner slider --> 
<link href="../css/animate.min.css" rel="stylesheet" type="text/css" media="all" /> 
<link href="../css/owl.carousel.css" rel="stylesheet" type="text/css" media="all"> <!-- carousel slider -->  
<!-- //Custom Theme files -->
<!-- font-awesome icons -->
<link href="../css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="../js/jquery-2.2.3.min.js"></script> 
<!-- //js --> 
<!-- web-fonts -->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lovers+Quarrel' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Offside' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Tangerine:400,700' rel='stylesheet' type='text/css'>
<!-- web-fonts --> 
<script src="../js/owl.carousel.js"></script>  
<script>
$(document).ready(function() { 
  $("#owl-demo").owlCarousel({ 
    autoPlay: 3000, //Set AutoPlay to 3 seconds 
    items :4,
    itemsDesktop : [640,5],
    itemsDesktopSmall : [480,2],
    navigation : true
 
  }); 
}); 
</script>
<script src="../js/jquery-scrolltofixed-min.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {

        // Dock the header to the top of the window when scrolled past the banner. This is the default behaviour.

        $('.header-two').scrollToFixed();  
        // previous summary up the page.

        var summaries = $('.summary');
        summaries.each(function(i) {
            var summary = $(summaries[i]);
            var next = summaries[i + 1];

            summary.scrollToFixed({
                marginTop: $('.header-two').outerHeight(true) + 10, 
                zIndex: 999
            });
        });
    });
</script>
<!-- start-smooth-scrolling -->
<script type="text/javascript" src="../js/move-top.js"></script>
<script type="text/javascript" src="../js/easing.js"></script> 
<script type="text/javascript">
    jQuery(document).ready(function($) {
      $(".scroll").click(function(event){   
        event.preventDefault();
        $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
      });
    });
</script>
<!-- //end-smooth-scrolling -->
<!-- smooth-scrolling-of-move-up -->
  <script type="text/javascript">
    $(document).ready(function() {
    
      var defaults = {
        containerID: 'toTop', // fading element id
        containerHoverID: 'toTopHover', // fading element hover id
        scrollSpeed: 1200,
        easingType: 'linear' 
      };
      
      $().UItoTop({ easingType: 'easeOutQuart' });
      
    });
  </script>
  <!-- //smooth-scrolling-of-move-up -->
<script src="../js/bootstrap.js"></script> 

</head>



<body>
    <div class="header">
    <div class="w3ls-header"><!--header-one--> 
      <div class="w3ls-header-left">
        <p><a href="#"></a></p>
      </div>
      <div class="w3ls-header-right">
        <ul>
          <li class="dropdown head-dpdn">
            <a href="login&page.php" class="dropdown-toggle" target="_blank"><i class="fa fa-credit-card-alt" aria-hidden="true"></i>Admin</a>
          </li>
          <!--<li class="dropdown head-dpdn">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user" aria-hidden="true"></i> My Account<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="login.html">Login </a></li> 
              <li><a href="signup.html">Sign Up</a></li> 
              <li><a href="login.html">My Orders</a></li>  
              <li><a href="login.html">Wallet</a></li> 
            </ul> 
          </li> 
          <li class="dropdown head-dpdn">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-percent" aria-hidden="true"></i> Today's Deals<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="offers.html">Cash Back Offers</a></li> 
              <li><a href="offers.html">Product Discounts</a></li>
              <li><a href="offers.html">Special Offers</a></li> 
            </ul> 
          </li> 
          <li class="dropdown head-dpdn">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-gift" aria-hidden="true"></i> Gift Cards<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="offers.html">Product Gift card</a></li> 
              <li><a href="offers.html">Occasions Register</a></li>
              <li><a href="offers.html">View Balance</a></li> 
            </ul> 
          </li> 
          <li class="dropdown head-dpdn">
            <a href="contact.html" class="dropdown-toggle"><i class="fa fa-map-marker" aria-hidden="true"></i> Store Finder</a>
          </li> 
          <li class="dropdown head-dpdn">
            <a href="card.html" class="dropdown-toggle"><i class="fa fa-credit-card-alt" aria-hidden="true"></i> Credit Card</a>
          </li> 
          <li class="dropdown head-dpdn">
            <a href="help.html" class="dropdown-toggle"><i class="fa fa-question-circle" aria-hidden="true"></i> Help</a>
          </li>-->
        </ul>
      </div>
      <div class="clearfix"> </div> 
    </div>
    <div class="header-two"><!-- header-two -->
      <div class="container">
        <div class="header-logo">
          <h1><a href="../index.php"><span>Card</span> <i>House BD</i></a></h1>
          
          
        </div>  
        <div class="header-search">
          <form action="#" method="post">
            <input type="search" name="Search" placeholder="Search for a Product..." required="">
            <button type="submit" class="btn btn-default" aria-label="Left Align">
              <i class="fa fa-search" aria-hidden="true"> </i>
            </button>
          </form>
        </div>
        <div class="header-cart"> 
          <div class="my-account">
            <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> CONTACT US</a>            
          </div>
          <div class="cart"> 
            <form action="#" method="post" class="last"> 
              <input type="hidden" name="cmd" value="_cart" />
              <input type="hidden" name="display" value="1" />
              <button class="w3view-cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
            </form>  
          </div>
          <div class="clearfix"> </div> 
        </div> 
        <div class="clearfix"> </div>
      </div>    
    </div><!-- //header-two -->
    
  <!-- //cart-js -->  
  <!-- countdown.js --> 
  <script src="../js/jquery.knob.js"></script>
  <script src="../js/jquery.throttle.js"></script>
  <script src="../js/jquery.classycountdown.js"></script>
    <script>
      $(document).ready(function() {
        $('#countdown1').ClassyCountdown({
          end: '1388268325',
          now: '1387999995',
          labels: true,
          style: {
            element: "",
            textResponsive: .5,
            days: {
              gauge: {
                thickness: .10,
                bgColor: "rgba(0,0,0,0)",
                fgColor: "#1abc9c",
                lineCap: 'round'
              },
              textCSS: 'font-weight:300; color:#fff;'
            },
            hours: {
              gauge: {
                thickness: .10,
                bgColor: "rgba(0,0,0,0)",
                fgColor: "#05BEF6",
                lineCap: 'round'
              },
              textCSS: ' font-weight:300; color:#fff;'
            },
            minutes: {
              gauge: {
                thickness: .10,
                bgColor: "rgba(0,0,0,0)",
                fgColor: "#8e44ad",
                lineCap: 'round'
              },
              textCSS: ' font-weight:300; color:#fff;'
            },
            seconds: {
              gauge: {
                thickness: .10,
                bgColor: "rgba(0,0,0,0)",
                fgColor: "#f39c12",
                lineCap: 'round'
              },
              textCSS: ' font-weight:300; color:#fff;'
            }

          },
          onEndCallback: function() {
            console.log("Time out!");
          }
        });
      });
    </script>
  <!-- //countdown.js -->
  <!-- menu js aim -->
  <script src="../js/jquery.menu-aim.js"> </script>
  <script src="../js/main.js"></script> <!-- Resource jQuery -->
</div>






<div id="wrapper" style ="margin-right:200px">
  <div id="header">
<?php
  global $product_id,$product_image,$product_price;
	$product_id=$_GET['id'];
  //echo $product_id;
  global $conn;
  $get_pro = "select * from product_info where id ='" .$product_id. "' "; 
  $run_get_pro = mysqli_query($conn, $get_pro);
  while ($row_pro = mysqli_fetch_array($run_get_pro)) {
  $product_id = $row_pro['id'];
  //echo $product_id;
  $product_name = $row_pro['product_name'];
  //echo $product_name;
  $product_desc = $row_pro['product_description'];
  //echo $product_desc;
  $product_image = $row_pro['product_logo_path'];
  //echo $product_image;
  $product_pri = $row_pro['product_price'];
  ?>
  <script>
    var im = "<?php echo json_encode($product_image); ?>";
    
  </script>

	

	<?php } ?>
		

	<?php
	 
	
	?>	
  
  </div>
  <!--header-->

  <div id="content" >

    <p id="textcount" style="position:absolute; left: 0px; visibility:hidden;font-size:30pt;"></p>
    <div id="instructions">
      <h3></h3>
    </div>
    
   <div id="container" style="float:left; margin-right:40px;margin-top:10px;border:2px solid white;" > 
    
	
				
	
	
	</div>
	
	  
    <div id="editor">
     
      <ul id="text" style="float: left; margin-right:10px;">
        <div id="spinner" class="spinner" style="display:none;margin-left:80px;margin-bottom:20px;"> Image Uploading<img src="images/ajax.png" alt="loading"> </div>
        <div id="container2" style="width:140px;"> </div>
        <li>
          <label>Text: </label>

          <input type="text" id="texts" placeholder="Add Text Here" />
        </li>
        <li>
          <label>Font Family: </label>
          <select id="fontfam">
            <option>Calibri</option>
            <option>Arial</option>
            <option>Verdana</option>
            <option>Impact</option>
            <option>Serif</option>
            <option>Monospace</option>
            <option>Helvetica</option>
            <option>Tahoma</option>
            <option>Gadget</option>
          </select>
        </li>
        <li>
          <label>Font Colour: </label>
          <select id="colour">
            <option>Black</option>
            <option>Red</option>
            <option>Blue</option>
            <option>Green</option>
            <option>White</option>
            <option>Yellow</option>
            <option>Pink</option>
            <option>Gray</option>
            <option>Purple</option>
            <option>Silver</option>
            <option>Gold</option>
            <option>Orange</option>
          </select>
        </li>
        <li>
          <label>Text Stroke Colour</label>
          <select id="textstroke">
            <option>transparent</option>
            <option>White</option>
            <option>Black</option>
            <option>Red</option>
            <option>Blue</option>
            <option>Green</option>
            <option>Yellow</option>
            <option>Pink</option>
            <option>Gray</option>
            <option>Purple</option>
            <option>Silver</option>
            <option>Gold</option>
            <option>Orange</option>
          </select>
        </li>
        <li>
          
          <input type="submit" id="textsubmit"  value="Add Text" style="background-color:#0280e1;color:white;"/>
		      <input type="submit" id="preview" value="Preview" style="background-color:#0280e1;color:white;"/>
           
        </li>
      </ul>
         
    <form action="cart.php?&id=<?php echo $product_id;?>" method="post">
         
                  <input type="hidden"  value="_cart" />
                  <input type="hidden"  value="1" /> 
                  <input type="hidden"  value="<?php echo $product_name; ?>"/> 
                  <input type="hidden"  value="<?php echo $product_pri; ?>"/>
                  <input type="submit" name="addcart" value="Add to cart"   style="margin-bottom:545px;width:15%;margin-left:770px">
		
			
			</form>	
			<?php
			global $quantity;
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
			if(isset($_POST['addcart'])){
				if(empty($_SESSION['cart'])){
					$_SESSION['cart'] = array();
				}
				array_push($_SESSION['cart'],$_GET[$product_id]);
				}
			}
		?>
		<form action="editor.php?&id=<?php echo $product_id; ?>" method="post">
			<input type="hidden" name="count" value="0" />
			<input type="hidden" name="price" value="<?php echo $product_pri; ?>" />
			<input type="hidden" name="name" value="<?php echo $product_name; ?>" />
			<input type="submit" name="cart" value="Cart" style="color:black"/>
		</form>
		
		
		
		
		
		
		
		
		
					
		
		
		<a href='checkout.php?&id=<?php echo $quantity ;?>'><input type="submit"/></a>
		
		
				  
				  
				  
				  </div>
      <script type="text/javascript">

        function writeMessage(messageLayer, message) {
        var context = messageLayer.getContext();
        messageLayer.clear();
        context.font = "18pt Calibri";
        context.fillStyle = "black";
        context.fillText(message, 10, 25);
      }
    
function update(group, activeAnchor) {

                var topLeft = group.get(".topLeft")[0];
                var topRight = group.get(".topRight")[0];
                var bottomRight = group.get(".bottomRight")[0];
                var bottomLeft = group.get(".bottomLeft")[0];
                var image = group.get(".image")[0];

                // update anchor positions
                 switch (activeAnchor.getName()) {
                     case "topLeft":
                         topRight.attrs.y = activeAnchor.attrs.y;
                         bottomLeft.attrs.x = activeAnchor.attrs.x;
                         if(topLeft.attrs.x >= topRight.attrs.x)
                         {return;}
                         break;
                     case "topRight":
                         topLeft.attrs.y = activeAnchor.attrs.y;
                         bottomRight.attrs.x = activeAnchor.attrs.x;
                         if(topRight.attrs.x <= topLeft.attrs.x)
                         {return;}
                         break;
                     case "bottomRight":
                         bottomLeft.attrs.y = activeAnchor.attrs.y;
                         topRight.attrs.x = activeAnchor.attrs.x;
                         if(bottomLeft.attrs.x >= topRight.attrs.x)
                         {return;}                                                         
                         break;
                     case "bottomLeft":
                         bottomRight.attrs.y = activeAnchor.attrs.y;
                         topLeft.attrs.x = activeAnchor.attrs.x;
                         if(bottomRight.attrs.x <= topLeft.attrs.x)
                         {return;}                                                                                             
                         break;
                 }

                image.setPosition(topLeft.attrs.x, topLeft.attrs.y);
                image.setSize(topRight.attrs.x - topLeft.attrs.x, bottomLeft.attrs.y - topLeft.attrs.y);
            }
             function addAnchor(group, x, y, name) {
                 var stage = group.getStage();
                 var layer = group.getLayer();

                 var anchor = new Kinetic.Circle({
                     x: x,
                     y: y,  
                     stroke: "transparent",
            //stroke: "blue",
                     fill: "transparent",
                     strokeWidth: 5,
                     radius: 35,
                     name: name,
                     draggable: true,
           dragBounds: {
             top: 10,
             right: stage.getWidth() -10,
             bottom: 450,
             left: 10
           }
                 });

                 anchor.on("dragmove", function() {
                     update(group, this);
                     layer.draw();
                 });
                 anchor.on("mousedown", function() {
                     group.draggable(false);
                     this.moveToTop();
                 });
                 anchor.on("dragend", function() {
                     group.draggable(true);
                     layer.draw();
                 });
                 // add hover styling
                 anchor.on("mouseover", function() {

                     var layer = this.getLayer();
                     document.body.style.cursor = "move";
                     this.setStrokeWidth(4);
                       this.setStroke("#FF0000");
                     fill: "#000";
                     strokeWidth: 2;
                     radius: 8;
            layer.draw();
                 });
               
                 anchor.on("mouseout", function() {
         
       
          
                     var layer = this.getLayer();
                     document.body.style.cursor = "default";
                     this.setStrokeWidth(2);
            this.setStroke("transparent");
            
                     layer.draw();
           
                 });
   
                 
                 group.add(anchor);
         
             }
            function loadImages(sources, callback) {
                var images = {};
                var loadedImages = 0;
                var numImages = 0;
                for(var src in sources) {
                    numImages++;
                }
                for(var src in sources) {
                    images[src] = new Image();
                    images[src].onload = function() {
                        if(++loadedImages >= numImages) {
                            callback(images);
                        }
                    };
                    images[src].src = sources[src];
                }
            }
            function initStage(images) {
               
                var stage = new Kinetic.Stage({
                    container: "container",
                    width: 691,
                    height: 440
                });
            
                var darthVaderGroup = new Kinetic.Group({
                    x: 300,
                    y: 80,
                    draggable: true,
          dragBounds: {
            top: 10,
            right: stage.getWidth() -300,
            bottom: 100,
            left: 10
          }
                });
                var yodaGroup = new Kinetic.Group({
                    x: 0,
                    y: 0,
                    draggable: false
                });
                var layer = new Kinetic.Layer();

                /*
                 * go ahead and add the groups
                 * to the layer and the layer to the
                 * stage so that the groups have knowledge
                 * of its layer and stage
                 */
         

    
        var simpleText = new Kinetic.Text({
     
        });
    
$('#save').click( function() {
    stage.toDataURL(function(dataUrl) {
       $.post("ajax.php", { data: dataUrl },
        function(data) {
            alert("Your Design Was Saved To The Server");
        });
    });
});



   document.getElementById("preview").addEventListener("click", function() {
                stage.toDataURL(function(dataUrl) {
                    /*
                     * here you can do anything you like with the data url.
                     * In this tutorial we'll just open the url with the browser
                     * so that you can see the result as an image
                     */
                    window.open(dataUrl, rel="lightbox");
          
                });
            }, false);
          
  $("ul#img a").click(function(){
        addProduct( $('img', this) );            
    });
        
   function addProduct( imgObj ){

       var layer = new Kinetic.Layer();

        var imageObj = new Image();
        imageObj.onload = function() {
          var image = new Kinetic.Image({
            x: stage.getWidth() / 2 - 53,
            y: stage.getHeight() / 2 - 59,
            image: imageObj,
            width: 106,
            height: 118,
      draggable: true
          });
            // add the shape to the layer
          layer.add(image);

          // add the layer to the stage
     stage.add(layer);
   
      image.on("mouseover", function(){
    var imagelayer = this.getLayer();
    document.body.style.cursor = "move"; 
    this.setStrokeWidth(1);
    this.setStroke("#000000");
  layer.draw();   
   writeMessage(messageLayer, "Drag Image Into Position Double Click To Remove");    
});
 image.on("mouseout", function(){
    var imagelayer = this.getLayer();
    document.body.style.cursor = "default"; 
    this.setStrokeWidth(0);
    this.setStroke("transparent");
  layer.draw();  
   writeMessage(messageLayer, "");       
});
image.on("dblclick dbltap", function(){
  layer.remove(image);
    layer.clear();
   layer.draw();
   });
        };
    
    
         imageObj.src = imgObj.attr('src');
 }

    
           $("ul#text #textsubmit").click(function(){
  
        addText();         
    });
  
  
function addText() {

        var text2 =  $('#texts').val();
       var fontfam = $('#fontfam').val();
       var colour = $('#colour').val();
       var textstroke = $('#textstroke').val();
       var width = document.getElementById("textcount").clientWidth;
       var height = document.getElementById("textcount").clientHeight;
       
           var length = text2.length;
         var rectwidth=width;
       
  var shapesLayer = new Kinetic.Layer();
    //add group
        var group = new Kinetic.Group({
        draggable: true
        });

      if(font==undefined)
    { var font=30; }
    
      if(x==undefined)
       {var x=250;}
       
     if(y==undefined)
        {var y=55;}
           var complexText = new Kinetic.Text({

          x: x,
          y: y,
          text: text2,
          fontSize: font,
          fontFamily: fontfam,
          textFill: colour,
          textStroke: textstroke

        });
    
    
     stage.add(shapesLayer);
     
     if(rectheight==undefined)
        { var rectheight=50; } 
    
     if(rectwidth==undefined)
       { var rectwidth=250; } 
    
    var rectx=250;
    var recty=40;
    
    
        var rect = new Kinetic.Rect({
          x: rectx,
          y: recty,
          width: rectwidth,
          height: rectheight,
          fill: "transparent",
          stroke: "black",
          strokeWidth: 1
        });    
    
      
    var recttrx=width+243;
    var recttry=32;
    var recttr= new Kinetic.Rect({
          x: recttrx,
          y: recttry,
          width: 15,
          height: 15,
          fill: "black",
          stroke: "red",
          strokeWidth: 1
        });    

    var rectbrx=width+243;
    var rectbry=82;   
    var rectbr= new Kinetic.Rect({
          x: rectbrx,
          y: rectbry,
          width: 15,
          height: 15,
          fill: "black",
          stroke: "red",
          strokeWidth: 1
        });    
    
    var recttlx=243;
    var recttly=32; 
    var recttl= new Kinetic.Rect({
          x: recttlx,
          y: recttly,
          width: 15,
          height: 15,
          fill: "black",
          stroke: "red",
          strokeWidth: 1
        });  
  
    var rectblx=243;
    var rectbly=82;   
    var rectbl= new Kinetic.Rect({
          x: rectblx,
          y: rectbly,
          width: 15,
          height: 15,
          fill: "black",
          stroke: "red",
          strokeWidth: 1
        })  
    

 
rect.on("mouseover dragmove", function() {
           var shapesLayer = this.getLayer();
           document.body.style.cursor = "move";
           recttl.setFill("black"); 
       recttl.setStroke("red"); 
           rectbl.setFill("black"); 
       rectbl.setStroke("red");
           rectbr.setFill("black"); 
       rectbr.setStroke("red");
           recttr.setFill("black"); 
       recttr.setStroke("red");
       rect.setStrokeWidth(1);
       rect.setStroke("black");      
           shapesLayer.draw();
    writeMessage(messageLayer, "Double Click To Remove Or Edit Text");
})
rect.on("mouseout", function() {
           var shapesLayer = this.getLayer();
           document.body.style.cursor = "default";
           recttl.setFill("transparent"); 
       recttl.setStroke("transparent"); 
           rectbl.setFill("transparent"); 
       rectbl.setStroke("transparent");
           rectbr.setFill("transparent"); 
       rectbr.setStroke("transparent");
           recttr.setFill("transparent"); 
       recttr.setStroke("transparent");
       rect.setStrokeWidth(0);
       rect.setStroke("transparent");
         shapesLayer.draw();
        writeMessage(messageLayer, ""); 
})

   
complexText.on("mouseover dragmove", function() {
           var shapesLayer = this.getLayer();
           document.body.style.cursor = "move";
           recttl.setFill("black"); 
       recttl.setStroke("red"); 
           rectbl.setFill("black"); 
       rectbl.setStroke("red");
           rectbr.setFill("black"); 
       rectbr.setStroke("red");
           recttr.setFill("black"); 
       recttr.setStroke("red");
       rect.setStrokeWidth(1);
       rect.setStroke("black");      
           shapesLayer.draw();
       writeMessage(messageLayer, "Drag Corners Increse Or Decrease Text Size"); 
})
complexText.on("mouseout", function() {
           var shapesLayer = this.getLayer();
           document.body.style.cursor = "default";
           recttl.setFill("transparent"); 
       recttl.setStroke("transparent"); 
           rectbl.setFill("transparent"); 
       rectbl.setStroke("transparent");
           rectbr.setFill("transparent"); 
       rectbr.setStroke("transparent");
           recttr.setFill("transparent"); 
       recttr.setStroke("transparent");
       rect.setStrokeWidth(0);
       rect.setStroke("transparent");
         shapesLayer.draw();
         writeMessage(messageLayer, "");
})
    group.add(complexText);
    group.add(rectbl);    
    group.add(recttr);
    group.add(rectbr);
    group.add(recttl);
    group.add(rect);
    shapesLayer.add(group);
    shapesLayer.draw();
    
    //bottom right square move start
      rectbr.on("mousedown.event1 dragmove", function () {
      var shapesLayer = this.getLayer();
      rectbr.moveToTop();
          document.body.style.cursor = "nw-resize";
          rectbr.setFill("red");
      var mousePos = stage.getMousePosition();
      var xpos=mousePos.x;
      var ypos=mousePos.y;
          shapesLayer.draw();
      //drag br
      group.on("dragmove.event2", function () {     
      var shapesLayer = this.getLayer();
          document.body.style.cursor = "nw-resize";
          rectbr.setFill("blue"); 
      //start  mouse position and font size 
      var dragmousePos = stage.getMousePosition();
      var dragxpos=dragmousePos.x;
      var dragypos=dragmousePos.y;
      
      if(dragypos > ypos)//drag increase
         {   
            if(font>50)
       {complexText.setFontSize(50);
     writeMessage(messageLayer, "Maximum Font Size Reached");
     complexText.setFontSize(font);  }
             else {
       font=(font + 1); 
  
    complexText.setFontSize(font);
     var textwidth=complexText.getTextWidth(); 
             rectwidth=(textwidth);
       rectbrx=244+textwidth;
       recttrx=244+textwidth;
       x=x+0;
       y=y-0.5;
       
      complexText.setPosition(x ,y);
        rect.setWidth(rectwidth);
      rect.setHeight(rectheight);
      rectbr.setPosition(rectbrx, rectbry);
      rectbl.setPosition(rectblx, rectbly);
      recttl.setPosition(recttlx, recttly);    
      recttr.setPosition(recttrx, recttry); 
      rect.setPosition(rectx, recty);
      writeMessage(messageLayer, "");
                               }
      }
      if(dragypos < ypos)//drag increase
         {   
       
            if(font<21)
       {complexText.setFontSize(20);
     writeMessage(messageLayer, "Minimum Font Size Reached");
     complexText.setFontSize(font);  }
             else {
       font=(font-1); 
  
    complexText.setFontSize(font);
     var textwidth=complexText.getTextWidth(); 
             rectwidth=(textwidth);
       rectbrx=rectblx+textwidth;
       recttrx=recttlx+textwidth;
       x=x+0;
       y=y+0.5;
       
      complexText.setPosition(x ,y);
        rect.setWidth(rectwidth);
      rect.setHeight(rectheight);
      rectbr.setPosition(rectbrx, rectbry);
      rectbl.setPosition(rectblx, rectbly);
      recttl.setPosition(recttlx, recttly);    
      recttr.setPosition(recttrx, recttry); 
      rect.setPosition(rectx, recty);
      writeMessage(messageLayer, "");
                               }
      }
          shapesLayer.draw();
      })
      })
      //end bottom right square
      
      
      //bottom left square move start
      rectbl.on("mousedown.event1 dragmove", function () {
      var shapesLayer = this.getLayer();
      rectbl.moveToTop();
          document.body.style.cursor = "nw-resize";
          rectbl.setFill("red");
      var mousePos = stage.getMousePosition();
      var xpos=mousePos.x;
      var ypos=mousePos.y;
          shapesLayer.draw();
      //drag br
      group.on("dragmove.event2", function () {     
      var shapesLayer = this.getLayer();
          document.body.style.cursor = "nw-resize";
          rectbl.setFill("blue"); 
      //start  mouse position and font size 
      var dragmousePos = stage.getMousePosition();
      var dragxpos=dragmousePos.x;
      var dragypos=dragmousePos.y;
      
      if(dragypos > ypos)//drag increase
         {   
            if(font>50)
       {complexText.setFontSize(50);
     writeMessage(messageLayer, "Maximum Font Size Reached");
     complexText.setFontSize(font);  }
             else {
       font=(font + 1); 
  
    complexText.setFontSize(font);
     var textwidth=complexText.getTextWidth(); 
             rectwidth=(textwidth);
       rectbrx=244+textwidth;
       recttrx=244+textwidth;
       x=x+0;
       y=y-0.5;
       
      complexText.setPosition(x ,y);
        rect.setWidth(rectwidth);
      rect.setHeight(rectheight);
      rectbr.setPosition(rectbrx, rectbry);
      rectbl.setPosition(rectblx, rectbly);
      recttl.setPosition(recttlx, recttly);    
      recttr.setPosition(recttrx, recttry); 
      rect.setPosition(rectx, recty);
      writeMessage(messageLayer, "");
                               }
      }
      if(dragypos < ypos)//drag increase
         {   
       
            if(font<21)
       {complexText.setFontSize(20);
     writeMessage(messageLayer, "Minimum Font Size Reached");
     complexText.setFontSize(font);  }
             else {
       font=(font-1); 
  
    complexText.setFontSize(font);
     var textwidth=complexText.getTextWidth(); 
             rectwidth=(textwidth);
       rectbrx=rectblx+textwidth;
       recttrx=recttlx+textwidth;
       x=x+0;
       y=y+0.5;
       
      complexText.setPosition(x ,y);
        rect.setWidth(rectwidth);
      rect.setHeight(rectheight);
      rectbr.setPosition(rectbrx, rectbry);
      rectbl.setPosition(rectblx, rectbly);
      recttl.setPosition(recttlx, recttly);    
      recttr.setPosition(recttrx, recttry); 
      rect.setPosition(rectx, recty);
      writeMessage(messageLayer, "");
                               }
      }
          shapesLayer.draw();
      })
      })
      //end bottom left square
      
      //top left right square move start
      recttl.on("mousedown.event1 dragmove", function () {
      var shapesLayer = this.getLayer();
      recttl.moveToTop();
          document.body.style.cursor = "nw-resize";
          recttl.setFill("red");
      var mousePos = stage.getMousePosition();
      var xpos=mousePos.x;
      var ypos=mousePos.y;
          shapesLayer.draw();
      //drag br
      group.on("dragmove.event2", function () {     
      var shapesLayer = this.getLayer();
          document.body.style.cursor = "nw-resize";
          recttl.setFill("blue"); 
      //start  mouse position and font size 
      var dragmousePos = stage.getMousePosition();
      var dragxpos=dragmousePos.x;
      var dragypos=dragmousePos.y;
      
      if(dragypos > ypos)//drag increase
         {   
            if(font>50)
       {complexText.setFontSize(50);
     writeMessage(messageLayer, "Maximum Font Size Reached");
     complexText.setFontSize(font);  }
             else {
       font=(font + 1); 
  
    complexText.setFontSize(font);
     var textwidth=complexText.getTextWidth(); 
             rectwidth=(textwidth);
       rectbrx=244+textwidth;
       recttrx=244+textwidth;
       x=x+0;
       y=y-0.5;
       
      complexText.setPosition(x ,y);
        rect.setWidth(rectwidth);
      rect.setHeight(rectheight);
      rectbr.setPosition(rectbrx, rectbry);
      rectbl.setPosition(rectblx, rectbly);
      recttl.setPosition(recttlx, recttly);    
      recttr.setPosition(recttrx, recttry); 
      rect.setPosition(rectx, recty);
      writeMessage(messageLayer, "");
                               }
      }
      if(dragypos < ypos)//drag increase
         {   
       
            if(font<21)
       {complexText.setFontSize(20);
     writeMessage(messageLayer, "Minimum Font Size Reached");
     complexText.setFontSize(font);  }
             else {
       font=(font-1); 
  
    complexText.setFontSize(font);
     var textwidth=complexText.getTextWidth(); 
             rectwidth=(textwidth);
       rectbrx=rectblx+textwidth;
       recttrx=recttlx+textwidth;
       x=x+0;
       y=y+0.5;
       
      complexText.setPosition(x ,y);
        rect.setWidth(rectwidth);
      rect.setHeight(rectheight);
      rectbr.setPosition(rectbrx, rectbry);
      rectbl.setPosition(rectblx, rectbly);
      recttl.setPosition(recttlx, recttly);    
      recttr.setPosition(recttrx, recttry); 
      rect.setPosition(rectx, recty);
      writeMessage(messageLayer, "");
                               }
      }
          shapesLayer.draw();
      })
      })
      //end bottom top left square
      
      
        //top right square move start
      recttr.on("mousedown.event1 dragmove", function () {
      var shapesLayer = this.getLayer();
      recttr.moveToTop();
          document.body.style.cursor = "nw-resize";
          recttr.setFill("red");
      var mousePos = stage.getMousePosition();
      var xpos=mousePos.x;
      var ypos=mousePos.y;
          shapesLayer.draw();
      //drag br
      group.on("dragmove.event2", function () {     
      var shapesLayer = this.getLayer();
          document.body.style.cursor = "nw-resize";
          recttr.setFill("blue"); 
      //start  mouse position and font size 
      var dragmousePos = stage.getMousePosition();
      var dragxpos=dragmousePos.x;
      var dragypos=dragmousePos.y;
      
      if(dragypos > ypos)//drag increase
         {   
            if(font>50)
       {complexText.setFontSize(50);
     writeMessage(messageLayer, "Maximum Font Size Reached");
     complexText.setFontSize(font);  }
             else {
       font=(font + 1); 
  
    complexText.setFontSize(font);
     var textwidth=complexText.getTextWidth(); 
             rectwidth=(textwidth);
       rectbrx=244+textwidth;
       recttrx=244+textwidth;
       x=x+0;
       y=y-0.5;
       
      complexText.setPosition(x ,y);
        rect.setWidth(rectwidth);
      rect.setHeight(rectheight);
      rectbr.setPosition(rectbrx, rectbry);
      rectbl.setPosition(rectblx, rectbly);
      recttl.setPosition(recttlx, recttly);    
      recttr.setPosition(recttrx, recttry); 
      rect.setPosition(rectx, recty);
      writeMessage(messageLayer, "");
                               }
      }
      if(dragypos < ypos)//drag increase
         {   
       
            if(font<21)
       {complexText.setFontSize(20);
     writeMessage(messageLayer, "Minimum Font Size Reached");
     complexText.setFontSize(font);  }
             else {
       font=(font-1); 
  
    complexText.setFontSize(font);
     var textwidth=complexText.getTextWidth(); 
             rectwidth=(textwidth);
       rectbrx=rectblx+textwidth;
       recttrx=recttlx+textwidth;
       x=x+0;
       y=y+0.5;
       
      complexText.setPosition(x ,y);
        rect.setWidth(rectwidth);
      rect.setHeight(rectheight);
      rectbr.setPosition(rectbrx, rectbry);
      rectbl.setPosition(rectblx, rectbly);
      recttl.setPosition(recttlx, recttly);    
      recttr.setPosition(recttrx, recttry); 
      rect.setPosition(rectx, recty);
      writeMessage(messageLayer, "");
                               }
      }
          shapesLayer.draw();
      })
      })
      //end top right square 
      
      
      //end square
          rect.on("dblclick", function(){
           // group.remove(complexText);
 var shapesLayer=this.getLayer();
 group.remove(complexText);
  group.remove(rect);
   group.remove(recttl);
    group.remove(recttr);
   group.remove(rectbl);
    group.remove(rectbr);
 shapesLayer.clear();
   shapesLayer.draw();
   });
   
   complexText.on("dblclick", function(){
        var shapesLayer=this.getLayer();
        group.remove(complexText);
        group.remove(rect);
          group.remove(recttl);
    group.remove(recttr);
   group.remove(rectbl);
    group.remove(rectbr);
 shapesLayer.clear();
   shapesLayer.draw();
   });
      //start dragging
  group.on("dragend", function() {
            rectbr.off("dragmove.event1");
            group.off("dragmove.event2");
      document.body.style.cursor = "default";
            }, false)
    
     
     group.on("dragend", function() {
            rectbl.off("dragmove.event1");
            group.off("dragmove.event2");
      document.body.style.cursor = "default";
            }, false)
    
     group.on("dragend", function() {
            recttl.off("dragmove.event1");
            group.off("dragmove.event2");
      document.body.style.cursor = "default";
            }, false) 
      
     group.on("dragend", function() {
            recttr.off("dragmove.event1");
            group.off("dragmove.event2");
      document.body.style.cursor = "default";
            }, false)
     //end dragging
     
    rectbr.on("mouseout", function () {
      var shapesLayer = this.getLayer();
      rectbr.setFill("#black");
        rectbr.off("dragmove.event1");
            group.off("dragmove.event2");
       document.body.style.cursor = "default";
      shapesLayer.draw();
      })
      rectbl.on("mouseout", function () {
      var shapesLayer = this.getLayer();
      rectbl.setFill("#black");
        rectbl.off("dragmove.event1");
            group.off("dragmove.event2");
       document.body.style.cursor = "default";
      shapesLayer.draw();
      })
      recttr.on("mouseout", function () {
      var shapesLayer = this.getLayer();
      recttr.setFill("#black");
        recttr.off("dragmove.event1");
            group.off("dragmove.event2");
       document.body.style.cursor = "default";
      shapesLayer.draw();
      })
      recttl.on("mouseout", function () {
      var shapesLayer = this.getLayer();
      recttl.setFill("#black");
        recttl.off("dragmove.event1");
            group.off("dragmove.event2");
       document.body.style.cursor = "default";
      shapesLayer.draw();
      })
      
    rectbr.on("mouseover dragmove", function () {
         var shapesLayer = this.getLayer();
         rect.setStrokeWidth(1);
       rect.setStroke("black");  
       recttl.setFill("black"); 
       recttl.setStroke("red"); 
           rectbl.setFill("black"); 
       rectbl.setStroke("red");
           rectbr.setFill("black"); 
       rectbr.setStroke("red");
           recttr.setFill("black"); 
       recttr.setStroke("red");
       rect.setStrokeWidth(1);
       rect.setStroke("black");      
           shapesLayer.draw(); 
       })
       
     rectbl.on("mouseover dragmove", function () {
         var shapesLayer = this.getLayer();
         rect.setStrokeWidth(1);
       rect.setStroke("black");  
       recttl.setFill("black"); 
       recttl.setStroke("red"); 
           rectbl.setFill("black"); 
       rectbl.setStroke("red");
           rectbr.setFill("black"); 
       rectbr.setStroke("red");
           recttr.setFill("black"); 
       recttr.setStroke("red");
       rect.setStrokeWidth(1);
       rect.setStroke("black");      
           shapesLayer.draw(); 
       })
       
  recttr.on("mouseover dragmove", function () {
         var shapesLayer = this.getLayer();
         rect.setStrokeWidth(1);
       rect.setStroke("black");  
       recttl.setFill("black"); 
       recttl.setStroke("red"); 
           rectbl.setFill("black"); 
       rectbl.setStroke("red");
           rectbr.setFill("black"); 
       rectbr.setStroke("red");
           recttr.setFill("black"); 
       recttr.setStroke("red");
       rect.setStrokeWidth(1);
       rect.setStroke("black");      
           shapesLayer.draw(); 
       })
       
 recttl.on("mouseover dragmove", function () {
         var shapesLayer = this.getLayer();
         rect.setStrokeWidth(1);
       rect.setStroke("black");  
       recttl.setFill("black"); 
       recttl.setStroke("red"); 
           rectbl.setFill("black"); 
       rectbl.setStroke("red");
           rectbr.setFill("black"); 
       rectbr.setStroke("red");
           recttr.setFill("black"); 
       recttr.setStroke("red");
       rect.setStrokeWidth(1);
       rect.setStroke("black");      
           shapesLayer.draw(); 
       })       
       
recttl.on("mouseout", function (){
  var shapeslayer= this.getLayer();
    recttl.setFill("transparent"); 
       recttl.setStroke("transparent"); 
           rectbl.setFill("transparent"); 
       rectbl.setStroke("transparent");
           rectbr.setFill("transparent"); 
       rectbr.setStroke("transparent");
           recttr.setFill("transparent"); 
       recttr.setStroke("transparent");
       rect.setStrokeWidth(0);
       rect.setStroke("transparent");
     shapesLayer.draw();    
})
recttr.on("mouseout", function (){
  var shapeslayer= this.getLayer();
    recttl.setFill("transparent"); 
       recttl.setStroke("transparent"); 
           rectbl.setFill("transparent"); 
       rectbl.setStroke("transparent");
           rectbr.setFill("transparent"); 
       rectbr.setStroke("transparent");
           recttr.setFill("transparent"); 
       recttr.setStroke("transparent");
       rect.setStrokeWidth(0);
       rect.setStroke("transparent");
     shapesLayer.draw();    
})

rectbl.on("mouseout", function (){
  var shapeslayer= this.getLayer();
    recttl.setFill("transparent"); 
       recttl.setStroke("transparent"); 
           rectbl.setFill("transparent"); 
       rectbl.setStroke("transparent");
           rectbr.setFill("transparent"); 
       rectbr.setStroke("transparent");
           recttr.setFill("transparent"); 
       recttr.setStroke("transparent");
       rect.setStrokeWidth(0);
       rect.setStroke("transparent");
     shapesLayer.draw();    
})

rectbr.on("mouseout", function (){
  var shapeslayer= this.getLayer();
    recttl.setFill("transparent"); 
       recttl.setStroke("transparent"); 
           rectbl.setFill("transparent"); 
       rectbl.setStroke("transparent");
           rectbr.setFill("transparent"); 
       rectbr.setStroke("transparent");
           recttr.setFill("transparent"); 
       recttr.setStroke("transparent");
       rect.setStrokeWidth(0);
       rect.setStroke("transparent");
     shapesLayer.draw();    
})

   
  
      //end mouse out of  squares


//end mouse out of  squares
      
            // add the shapes to the layer
          shapesLayer.add(group);
        
           
    
            // add the shape to the layer
        
            // add the layer to the stage   
}
//end text editor
  
  

        // add the shapes to the layer
                layer.add(yodaGroup);
        layer.add(darthVaderGroup);
        
                stage.add(layer);

                // darth vader
                var darthVaderImg = new Kinetic.Image({
                    x: 0,
                    y: 0,
                    image: images.darthVader,
                    width: 300,
                    height: 320,
                    strokeWidth: 2,
                     stroke: "black",
                     name: "image"
    });
darthVaderImg.on("mouseover", function() {
                     var layer = this.getLayer();
                     document.body.style.cursor = "cursor";
                     this.setStrokeWidth(2);
            this.setStroke("black");
                     layer.draw();
           writeMessage(messageLayer, "Drag Image Into Position Click And Drag The Corners To Re-size");
           
                 });
darthVaderImg.on("mouseout", function() {
                     var layer = this.getLayer();
                     document.body.style.cursor = "default";
                     this.setStrokeWidth(0);
            this.setStroke("transparent");
                     layer.draw();
            writeMessage(messageLayer, "");
           
                 });         

var messageLayer = new Kinetic.Layer();
    stage.add(messageLayer);
    
                darthVaderGroup.add(darthVaderImg);
                addAnchor(darthVaderGroup, 0, 0, "topLeft");
                addAnchor(darthVaderGroup, 300, 0, "topRight");
                addAnchor(darthVaderGroup, 300, 320, "bottomRight");
                addAnchor(darthVaderGroup, 0, 320, "bottomLeft");

                // yoda
                var yodaImg = new Kinetic.Image({
                    x: 0,
                    y: 0,
                    image: images.yoda,
                    width: 691,
                    height: 450,
                    name: "image"
                });

                yodaGroup.add(yodaImg);
               
                stage.draw();
            }
      

            window.onload = function() {
                var sources = {
          
                    
                  yoda: <?php echo json_encode($product_image,JSON_UNESCAPED_SLASHES) ?>
                };
                loadImages(sources, initStage);
        
            };
      
$(window).load( function() { 

 var stage2 = new Kinetic.Stage({
          container: "container2",
          width: 130,
          height: 40
 })

 $("ul#text #texts").keyup(function(){
           
         addText2();
     });
 $("ul#text #fontfam").change(function(){
           
         addText2();
     });   
   
   $("ul#text #colour").change(function(){
           
         addText2();
     });   
    $("ul#text #textstroke").change(function(){
           
         addText2();
     });  
function addText2() {

        var text3 =  $('#texts').val();
       var fontfam3 = $('#fontfam').val();
       var colour3 = $('#colour').val();
       var textstroke3 = $('#textstroke').val();

       var font3=23;
  var shapesLayer2 = new Kinetic.Layer();


 
           var complexText2 = new Kinetic.Text({

          x: 10,
          y: 12,
          text: text3,
          fontSize: font3,
          fontFamily: fontfam3,
          textFill: colour3,
          textStroke: textstroke3

        });

         stage2.clear();
   shapesLayer2.draw();

         
        // add the shapes to the layer
        shapesLayer2.add(complexText2);
 
        stage2.add(shapesLayer2);
     };
      });
    
    $("#texts").keyup(function () {
      var value = $(this).val();
      $("p#textcount").text(value);
         var fontid =  $('#fontfam').val();
         $("p#textcount").css("font-family", fontid);
       var color =  $('#colour').val();
             $("p#textcount").css("color", color);  
    }).keyup();
  
      
  
        $("#fontfam").change(function () {
      var value = $('texts').val();
      $("p#textcount").text(value);
         var fontid =  $('#fontfam').val();
         $("p#textcount").css("font-family", fontid);
       var color =  $('#colour').val();
            $("p#textcount").css("color", color);  
    }).keyup();   





      </script>




	  <br/>
      
	  
      
	 




      <p class="clearing" /></p>
   
  

  <div class="row">
        
          <div class="col-md-12">
            <h1>Product Description</h1>
            <?php echo $product_desc; ?>
          </div>
          
         

      </div>

  
  <!--footer--> 
</div>



<!--container--> 
<script>
    $("#texts").keyup(function () {
      var value = $(this).val();
      $("p#textcount").text(value);
	  	   var fontid =  $('#fontfam').val();
		     $("p#textcount").css("font-family", fontid);
		   var color =  $('#colour').val();
             $("p#textcount").css("color", color);  
    }).keyup();
	
	    $("#colour").change(function () {
      var value = $('texts').val();
      $("p#textcount").text(value);
	  	   var fontid =  $('#fontfam').val();
		     $("p#textcount").css("font-family", fontid);
		   var color =  $('#colour').val();
             $("p#textcount").css("color", color);  
    }).keyup();
	
		    $("#fontfam").change(function () {
      var value = $('texts').val();
      $("p#textcount").text(value);
	  	   var fontid =  $('#fontfam').val();
		     $("p#textcount").css("font-family", fontid);
		   var color =  $('#colour').val();
             $("p#textcount").css("color", color);  
    }).keyup();
	
	
</script>

<div class="footer" style="width:1100px;">
    <div class="container">
      <!--<div class="footer-info w3-agileits-info">
        <div class="col-md-4 address-left agileinfo">
          <div class="footer-logo header-logo">
            <h2><a href="#"><span>S</span>mart <i>Bazaar</i></a></h2>
            <h6>Your stores. Your place.</h6>
          </div>
          <ul>
            <li><i class="fa fa-map-marker"></i> 123 San Sebastian, New York City USA.</li>
            <li><i class="fa fa-mobile"></i> 333 222 3333 </li>
            <li><i class="fa fa-phone"></i> +222 11 4444 </li>
            <li><i class="fa fa-envelope-o"></i> <a href="mailto:example@mail.com"> mail@example.com</a></li>
          </ul> 
        </div>
        <div class="col-md-8 address-right">
          <div class="col-md-4 footer-grids">
            <h3>Company</h3>
            <ul>
              <li><a href="about.html">About Us</a></li>
              <li><a href="marketplace.html">Marketplace</a></li>  
              <li><a href="values.html">Core Values</a></li>  
              <li><a href="privacy.html">Privacy Policy</a></li>
            </ul>
          </div>
          <div class="col-md-4 footer-grids">
            <h3>Services</h3>
            <ul>
              <li><a href="contact.html">Contact Us</a></li>
              <li><a href="login.html">Returns</a></li> 
              <li><a href="faq.html">FAQ</a></li>
              <li><a href="sitemap.html">Site Map</a></li>
              <li><a href="login.html">Order Status</a></li>
            </ul> 
          </div>
          <div class="col-md-4 footer-grids">
            <h3>Payment Methods</h3>
            <ul>
              <li><i class="fa fa-laptop" aria-hidden="true"></i> Net Banking</li>
              <li><i class="fa fa-money" aria-hidden="true"></i> Cash On Delivery</li>
              <li><i class="fa fa-pie-chart" aria-hidden="true"></i>EMI Conversion</li>
              <li><i class="fa fa-gift" aria-hidden="true"></i> E-Gift Voucher</li>
              <li><i class="fa fa-credit-card" aria-hidden="true"></i> Debit/Credit Card</li>
            </ul>  
          </div>
          <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
      </div>-->
    </div>
  </div>
  <!-- //footer -->   
  <!--<div class="copy-right"> 
    <div class="container">
      <p> All rights reserved | Design by </a></p>
    </div>
  </div>-->
  <!-- cart-js -->
  <script src="../js/minicart.js"></script>
  
 
       <script>
        w3ls.render();

        w3ls.cart.on('w3sb_checkout', function (evt) {
          var items, len, i;

          if (this.subtotal() > 0) {
            items = this.items();

            for (i = 0, len = items.length; i < len; i++) {
              items[i].set('shipping', 0);
              items[i].set('shipping2', 0);
            }
          }
        });
    </script>  
  
 
  <!-- //cart-js -->  
  <!-- countdown.js --> 
  <script src="../js/jquery.knob.js"></script>
  <script src="../js/jquery.throttle.js"></script>
  <script src="../js/jquery.classycountdown.js"></script>
    <script>
      $(document).ready(function() {
        $('#countdown1').ClassyCountdown({
          end: '1388268325',
          now: '1387999995',
          labels: true,
          style: {
            element: "",
            textResponsive: .5,
            days: {
              gauge: {
                thickness: .10,
                bgColor: "rgba(0,0,0,0)",
                fgColor: "#1abc9c",
                lineCap: 'round'
              },
              textCSS: 'font-weight:300; color:#fff;'
            },
            hours: {
              gauge: {
                thickness: .10,
                bgColor: "rgba(0,0,0,0)",
                fgColor: "#05BEF6",
                lineCap: 'round'
              },
              textCSS: ' font-weight:300; color:#fff;'
            },
            minutes: {
              gauge: {
                thickness: .10,
                bgColor: "rgba(0,0,0,0)",
                fgColor: "#8e44ad",
                lineCap: 'round'
              },
              textCSS: ' font-weight:300; color:#fff;'
            },
            seconds: {
              gauge: {
                thickness: .10,
                bgColor: "rgba(0,0,0,0)",
                fgColor: "#f39c12",
                lineCap: 'round'
              },
              textCSS: ' font-weight:300; color:#fff;'
            }

          },
          onEndCallback: function() {
            console.log("Time out!");
          }
        });
      });
    </script>
  <!-- //countdown.js -->
  <!-- menu js aim -->
  <script src="../js/jquery.menu-aim.js"> </script>
  <script src="../js/main.js"></script> <!-- Resource jQuery -->
  <!-- //menu js aim --> 
  <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster --> 
</body>
</html>


