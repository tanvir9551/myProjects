<!DOCTYPE HTML>
<html>
	<head>
		<?php include'header.php';?>
		<title>Trade Net Tech</title>
	</head>
	<body style="background:#236476;">	
		<?php include'nav.php';?>
		<div class = "container">
			<div class="services-grids">
				<div class="content">
					<h3>Our valuable clients</h3>
					<div class="product-grid">
					<img src="images/ucb.png">
					<h4>United Commercial Bank Ltd.</h4>
					</div>
					<div class="product-grid">
					<img src="images/nologo.png">
					<h4>Global SAS Trade Ltd.</h4>
					</div>
					<div class="product-grid">
					<img src="images/nologo.png">
					<h4>Fair Trade International </h4>
					</div>
					<div class="product-grid">
					<img src="images/nologo.png">
					<h4>Mayeshas Fashion</h4>
					</div>
					<div class="product-grid">
					<img src="images/primeasset.png">
					<h4>Prime Asset Group</h4>
					</div>
					<div class="product-grid">
					<img src="images/mirTelecom.png">
					<h4>Mir Telecom</h4>
					</div>
					<div class="product-grid">
					<img src="images/ansar-vdp.png">
					<h4>Ansar & VDP Head Quarter</h4>
					</div>
					<div class="product-grid">
					<img src="images/banglaTel.png">
					<h4>bangla tel</h4>
					</div>
					<div class="product-grid">
					<img src="images/hishab.png">
					<h4>HISHAB</h4>
					</div>
					<div class="product-grid">
					<img src="images/nologo.png">
					<h4>basic group</h4>
					</div>
					<div class="product-grid">
					<img src="images/deshbandhu.png">
					<h4>basic group</h4>
					</div>
				</div>
			</div>
		<div class="clear"> </div>
		<div class="clear"> </div>
		<?php include'footer.php';?>
		</div>
	</body>
</html>

