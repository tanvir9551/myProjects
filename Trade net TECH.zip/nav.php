<div class = "nav-bar"><p>One stop solutions</p></div>
		<nav class="navbar navbar-toggleable-sm navbar-light">
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style = "border: none;">
				<span><img src="images/toggle.png" height = "30px"></span>
			</button>
			<div class = "logo"><a href="index.php"><div><img src="images/logo.png" title="logo"><font color = "#73B669">trade <font color = "#236476">net</font> tech</font></div></a></div>
			

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
			  <li class="nav-item">
				<a class="nav-link" href="index.php" style = "color:#73B669" onMouseOver="this.style.color='#236476'" onMouseOut="this.style.color='#73B669'">Home</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="services.php" style = "color:#73B669" onMouseOver="this.style.color='#236476'" onMouseOut="this.style.color='#73B669'">services</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="works.php" style = "color:#73B669" onMouseOver="this.style.color='#236476'" onMouseOut="this.style.color='#73B669'">clients</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="contact.php" style = "color:#73B669" onMouseOver="this.style.color='#236476'" onMouseOut="this.style.color='#73B669'">contact</a>
			  </li>
			  <li class="nav-item">
				<div class="dropdown">
					<a class="nav-link" href="#" style = "color:#73B669" onMouseOver="this.style.color='#236476'" onMouseOut="this.style.color='#73B669'">&#709;</a>
					<div class="dropdown-content">
						<a href="https://portal.tradenettech.com" target = "_blank">login</a>
   					</div>
				</div>

			  </li>
			</ul>
		  </div>
		</nav>
		<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
		<script src="bootstrap/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
	
	</body>