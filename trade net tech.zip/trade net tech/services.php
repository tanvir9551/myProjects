<!DOCTYPE HTML>
<html>
	<head>
		<?php include'header.php';?>
		<title>Trade Net Tech</title>
	</head>
	<body style="background:#236476;">	
		<?php include'nav.php';?>
		<div class = "content">
			<h3>our services</h3>
			<div class="services-grid">
					<h3>laptops/desktops</h3>
					<img src="images/laptops.png" title="img1" title="img1"/>
					<p>Technology products we offer are HP, Dell, Lenevo, Acer, Apple, Asus and other renowned brands.</p>
			</div>
			<div class="services-grid">
					<h3>IT consumable products</h3>
					<img src="images/itc.png" title="IT consumable products"/>
					<p>All Kinds of  Printer Toner and Cartridges, Ribbon, Data Tape, RAM, HDD, CD / DVD, Mass storage Devices, Mouse, Keyboard, Printer Maintenance Kit, Photocopier Spares.</p>
			</div>
			<div class="services-grid">
					<h3>office stationaries</h3>
					<img src="images/stationary.png" title="Office Stationaries"/>
					<p>All Kind of  Office Stationeries</p>
			</div>
			<div class="services-grid">
					<h3>network devices</h3>
					<img src="images/router.png" title="Network Devices"/>
					<p>Switch, Router, LAN/WAN, Network Setup</p>
			</div>
			<div class="services-grid">
					<h3>software development & solutions</h3>
					<img src="images/software.png" title="Software Solutions"/>
					<p>All kinds of software development and solutions for corporate house and home user are done. Software development  includes Desktop and web applications and also graphics designing</p>
			</div>
			<div class="services-grid">
					<h3>other electronic needs</h3>
					<img src="images/others.png" title="Software Solutions"/>
					<p>An office can't be limited only with paperworks and deals. To run a business it should have a proper environment. Our company provides all kinds of electronics and other things needed for creating a perfect office environment for you.</p>
					<p></p>
			</div>
		</div>
		<div class="clear"> </div>
		<?php include'footer.php';?>
	</body>
</html>

