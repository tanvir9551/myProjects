<!DOCTYPE HTML>
<html>
	<head>
		<?php include'header.php';?>
		<title>Trade Net Tech</title>
	</head>
	<body style="background:#236476;">	
		<?php include'nav.php';?>
		<div class = "member">
			<img src = "images/no_avatar.jpg">
			<h1>AHM Rakibul Haque</h1>
			<p>Managing Partner<br>Email: rakibul.haque@tradenettech.com</p>
		</div>
		<div class = "member">
			<img src = "images/no_avatar.jpg">
			<h1>Md Asifur Rahman</h1>
			<p>Managing Partner<br>Email: asifur.rahman@tradenettech.com</p>
		</div>
		<div class = "member">
			<img src = "images/no_avatar.jpg">
			<h1>Mir Asaduzzaman Rana</h1>
			<p>Director Operation</p>
		</div>
		<div class = "member">
			<img src = "images/no_avatar.jpg">
			<h1>Nigar Sultana</h1>
			<p>Human Resource</p>
		</div>
		<div class = "member">
			<img src = "images/no_avatar.jpg">
			<h1>Md Waziul Islam</h1>
			<p>Marketing and Sustainability</p>
		</div>
		<div class = "member">
			<img src = "images/no_avatar.jpg">
			<h1>Farhana Yeasmin Liza</h1>
			<p>Accounts and Finance</p>
		</div>
		<div class = "member">
			<img src = "images/no_avatar.jpg">
			<h1>Md Arifur Rahman</h1>
			<p>E-Commerce</p>
		</div>
		<div class="clear"> </div>
		<?php include'footer.php';?>
	</body>
</html>

