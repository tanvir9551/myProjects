<div class="footer-nav">
	<div class="wrap">
		<ul class="social">
			<li><h4>Find Us On:</h4></li>
			<li><a href="https://www.facebook.com/tradenettech.bd/" target = "_blank"><img src="images/face.jpg" title="facebook"/></a></li>
			<li><a href="#"><img src="images/twit.jpg" title="twitter"/></a></li>
			<li><a href="#"><img src="images/in.jpg" title="google+"/></a></li>
		</ul>		
	</div>
	<div class = "clear"></div>
</div>