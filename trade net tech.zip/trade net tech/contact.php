<!DOCTYPE HTML>
<html>
	<head>
		<?php include'header.php';?>
		<title>Trade Net Tech</title>
	</head>
	<body style="background:#236476;">	
		<?php include'nav.php';?>
		<div class = "content">
			<div class="contact">
				<h3>contact us</h3>
				<div class="contact-from">
					<form id="form" class="blocks" action="#" method="post">
						<p>
							<label>Name:</label>
							<input type="text" class="text" name="name" disabled>
						</p>
						<div class = "clear"></div>
						<p>
							<label>Company:</label>
							<input type="text" class="text" name="company" disabled>
						</p>
						<div class = "clear"></div>
						<p>
							<label>Your e-mail:</label>
							<input type="text" class="text" name="email" disabled>
						</p>
						<div class = "clear"></div>
						<p>
							<label>Contact number:</label>
							<input type="text" class="text" name="phone" disabled>
						</p>
						<div class = "clear"></div>
						<p class="area">
							<label>Message:</label>
							<textarea placeholder = "We are working on it. If you have any query please e-mail us at support@tradenettech.com" class="textarea" name="message" disabled></textarea>
						</p>
						<p>							
							<input type="submit" class="btn" value="Submit" disabled>
						</p>
					</form>
					<span class = "message">hbvhjbjhbhj</span>
				</div>
				<br><br>
				<ul>
					<li><h3>Corporate Office</h3><p>House # 23,  Road # 08 ,Level-7<br>South Baridhara (DIT Project), Merul Badda<br>Dhaka-1212, Bangladesh</p></li>
				</ul>
				<br>
				<ul>
					<li><h3>Sales Office</h3><p>House # 53,  Road # 19, Sector # 14<br>Uttara Model Town<br>Dhaka-1212, Bangladesh</p></li>
				</ul>
				<br>
				<ul>
					<li><p>&#9993; support@tradenettech.com</p></li>
				</ul>
				<br>
				<ul>
					<li><p>&#9990; 01717263608(24x7)</p></li>
					<li><p>&#9990; 01752776566 (Support)</p></li>
				</ul>
			</div>
		</div>					
		<div class="clear"> </div>
		<?php include'footer.php';?>			
	</body>
</html>

