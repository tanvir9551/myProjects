		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href = "css/style.css" rel = "stylesheet">
		<link href = "images/logo.png" rel = "icon" sizes = "16x16" type = "image/png" />
		<link rel = "stylesheet prefetch" href = "plugins/aos/aos.css">
		<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">