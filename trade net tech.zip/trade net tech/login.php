<!DOCTYPE HTML>
<html>
	<head>
		<?php include'header.php';?>
		<title>Trade Net Tech</title>
	</head>
	<body style="background:#236476;">
		<div class = "navbar" align = "center">
			<div class = "logo"><a href="index.php"><div><img src="images/logo.png" title="logo"><font color = "#73B669">trade <font color = "#236476">net</font> tech</font></div></a></div>
		</div>	
		<div class = "login-form">
			<form name="myForm" action="#" onsubmit="return validateForm()" method="get">
				Username:<br><input type = "text" name = "username" required><br><br>
				Password:<br><input type = "password" name = "password" required><br><br>
				<input type = "submit" value = "Log In" class = "login-button">
			</form>
			<a href = "#">Problem accessing account?</a>
			<div class = "clear"></div>
		</div>
		<script type = "text/javascript">
			function validateForm() {
				var x = document.forms["myForm"]["username"].value;
				if (x == "") {
					alert("username required");
					return false;
				}
				else alert("working on it");
			}
		</script>
	</body>
</html>

